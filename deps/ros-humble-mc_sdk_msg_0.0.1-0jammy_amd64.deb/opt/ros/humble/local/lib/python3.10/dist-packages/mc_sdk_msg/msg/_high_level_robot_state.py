# generated from rosidl_generator_py/resource/_idl.py.em
# with input from mc_sdk_msg:msg/HighLevelRobotState.idl
# generated code does not contain a copyright notice


# Import statements for member types

# Member 'reserved_int'
# Member 'reserved_ft'
# Member 'reserved_uint'
import array  # noqa: E402, I100

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

# Member 'q'
# Member 'qd'
import numpy  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_HighLevelRobotState(type):
    """Metaclass of message 'HighLevelRobotState'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('mc_sdk_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'mc_sdk_msg.msg.HighLevelRobotState')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__high_level_robot_state
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__high_level_robot_state
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__high_level_robot_state
            cls._TYPE_SUPPORT = module.type_support_msg__msg__high_level_robot_state
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__high_level_robot_state

            from geometry_msgs.msg import Vector3
            if Vector3.__class__._TYPE_SUPPORT is None:
                Vector3.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class HighLevelRobotState(metaclass=Metaclass_HighLevelRobotState):
    """Message class 'HighLevelRobotState'."""

    __slots__ = [
        '_pos',
        '_vel_world',
        '_rpy',
        '_vel',
        '_acc',
        '_gyro',
        '_q',
        '_qd',
        '_reserved_int',
        '_reserved_ft',
        '_reserved_uint',
    ]

    _fields_and_field_types = {
        'pos': 'geometry_msgs/Vector3',
        'vel_world': 'geometry_msgs/Vector3',
        'rpy': 'geometry_msgs/Vector3',
        'vel': 'geometry_msgs/Vector3',
        'acc': 'geometry_msgs/Vector3',
        'gyro': 'geometry_msgs/Vector3',
        'q': 'float[12]',
        'qd': 'float[12]',
        'reserved_int': 'sequence<int32>',
        'reserved_ft': 'sequence<double>',
        'reserved_uint': 'sequence<uint32>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 12),  # noqa: E501
        rosidl_parser.definition.Array(rosidl_parser.definition.BasicType('float'), 12),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('int32')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('double')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('uint32')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from geometry_msgs.msg import Vector3
        self.pos = kwargs.get('pos', Vector3())
        from geometry_msgs.msg import Vector3
        self.vel_world = kwargs.get('vel_world', Vector3())
        from geometry_msgs.msg import Vector3
        self.rpy = kwargs.get('rpy', Vector3())
        from geometry_msgs.msg import Vector3
        self.vel = kwargs.get('vel', Vector3())
        from geometry_msgs.msg import Vector3
        self.acc = kwargs.get('acc', Vector3())
        from geometry_msgs.msg import Vector3
        self.gyro = kwargs.get('gyro', Vector3())
        if 'q' not in kwargs:
            self.q = numpy.zeros(12, dtype=numpy.float32)
        else:
            self.q = kwargs.get('q')
        if 'qd' not in kwargs:
            self.qd = numpy.zeros(12, dtype=numpy.float32)
        else:
            self.qd = kwargs.get('qd')
        self.reserved_int = array.array('i', kwargs.get('reserved_int', []))
        self.reserved_ft = array.array('d', kwargs.get('reserved_ft', []))
        self.reserved_uint = array.array('I', kwargs.get('reserved_uint', []))

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.pos != other.pos:
            return False
        if self.vel_world != other.vel_world:
            return False
        if self.rpy != other.rpy:
            return False
        if self.vel != other.vel:
            return False
        if self.acc != other.acc:
            return False
        if self.gyro != other.gyro:
            return False
        if any(self.q != other.q):
            return False
        if any(self.qd != other.qd):
            return False
        if self.reserved_int != other.reserved_int:
            return False
        if self.reserved_ft != other.reserved_ft:
            return False
        if self.reserved_uint != other.reserved_uint:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def pos(self):
        """Message field 'pos'."""
        return self._pos

    @pos.setter
    def pos(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'pos' field must be a sub message of type 'Vector3'"
        self._pos = value

    @builtins.property
    def vel_world(self):
        """Message field 'vel_world'."""
        return self._vel_world

    @vel_world.setter
    def vel_world(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'vel_world' field must be a sub message of type 'Vector3'"
        self._vel_world = value

    @builtins.property
    def rpy(self):
        """Message field 'rpy'."""
        return self._rpy

    @rpy.setter
    def rpy(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'rpy' field must be a sub message of type 'Vector3'"
        self._rpy = value

    @builtins.property
    def vel(self):
        """Message field 'vel'."""
        return self._vel

    @vel.setter
    def vel(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'vel' field must be a sub message of type 'Vector3'"
        self._vel = value

    @builtins.property
    def acc(self):
        """Message field 'acc'."""
        return self._acc

    @acc.setter
    def acc(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'acc' field must be a sub message of type 'Vector3'"
        self._acc = value

    @builtins.property
    def gyro(self):
        """Message field 'gyro'."""
        return self._gyro

    @gyro.setter
    def gyro(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'gyro' field must be a sub message of type 'Vector3'"
        self._gyro = value

    @builtins.property
    def q(self):
        """Message field 'q'."""
        return self._q

    @q.setter
    def q(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'q' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 12, \
                "The 'q' numpy.ndarray() must have a size of 12"
            self._q = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 12 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'q' field must be a set or sequence with length 12 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._q = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def qd(self):
        """Message field 'qd'."""
        return self._qd

    @qd.setter
    def qd(self, value):
        if isinstance(value, numpy.ndarray):
            assert value.dtype == numpy.float32, \
                "The 'qd' numpy.ndarray() must have the dtype of 'numpy.float32'"
            assert value.size == 12, \
                "The 'qd' numpy.ndarray() must have a size of 12"
            self._qd = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 len(value) == 12 and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'qd' field must be a set or sequence with length 12 and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._qd = numpy.array(value, dtype=numpy.float32)

    @builtins.property
    def reserved_int(self):
        """Message field 'reserved_int'."""
        return self._reserved_int

    @reserved_int.setter
    def reserved_int(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'i', \
                "The 'reserved_int' array.array() must have the type code of 'i'"
            self._reserved_int = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, int) for v in value) and
                 all(val >= -2147483648 and val < 2147483648 for val in value)), \
                "The 'reserved_int' field must be a set or sequence and each value of type 'int' and each integer in [-2147483648, 2147483647]"
        self._reserved_int = array.array('i', value)

    @builtins.property
    def reserved_ft(self):
        """Message field 'reserved_ft'."""
        return self._reserved_ft

    @reserved_ft.setter
    def reserved_ft(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'd', \
                "The 'reserved_ft' array.array() must have the type code of 'd'"
            self._reserved_ft = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -1.7976931348623157e+308 or val > 1.7976931348623157e+308) or math.isinf(val) for val in value)), \
                "The 'reserved_ft' field must be a set or sequence and each value of type 'float' and each double in [-179769313486231570814527423731704356798070567525844996598917476803157260780028538760589558632766878171540458953514382464234321326889464182768467546703537516986049910576551282076245490090389328944075868508455133942304583236903222948165808559332123348274797826204144723168738177180919299881250404026184124858368.000000, 179769313486231570814527423731704356798070567525844996598917476803157260780028538760589558632766878171540458953514382464234321326889464182768467546703537516986049910576551282076245490090389328944075868508455133942304583236903222948165808559332123348274797826204144723168738177180919299881250404026184124858368.000000]"
        self._reserved_ft = array.array('d', value)

    @builtins.property
    def reserved_uint(self):
        """Message field 'reserved_uint'."""
        return self._reserved_uint

    @reserved_uint.setter
    def reserved_uint(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'I', \
                "The 'reserved_uint' array.array() must have the type code of 'I'"
            self._reserved_uint = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, int) for v in value) and
                 all(val >= 0 and val < 4294967296 for val in value)), \
                "The 'reserved_uint' field must be a set or sequence and each value of type 'int' and each unsigned integer in [0, 4294967295]"
        self._reserved_uint = array.array('I', value)
