# generated from rosidl_generator_py/resource/_idl.py.em
# with input from mc_sdk_msg:msg/HighLevelCmd.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_HighLevelCmd(type):
    """Metaclass of message 'HighLevelCmd'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('mc_sdk_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'mc_sdk_msg.msg.HighLevelCmd')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__high_level_cmd
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__high_level_cmd
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__high_level_cmd
            cls._TYPE_SUPPORT = module.type_support_msg__msg__high_level_cmd
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__high_level_cmd

            from geometry_msgs.msg import Vector3
            if Vector3.__class__._TYPE_SUPPORT is None:
                Vector3.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class HighLevelCmd(metaclass=Metaclass_HighLevelCmd):
    """Message class 'HighLevelCmd'."""

    __slots__ = [
        '_control_mode',
        '_motion_mode',
        '_cmd_vel',
        '_cmd_angular',
    ]

    _fields_and_field_types = {
        'control_mode': 'uint32',
        'motion_mode': 'uint32',
        'cmd_vel': 'geometry_msgs/Vector3',
        'cmd_angular': 'geometry_msgs/Vector3',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Vector3'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.control_mode = kwargs.get('control_mode', int())
        self.motion_mode = kwargs.get('motion_mode', int())
        from geometry_msgs.msg import Vector3
        self.cmd_vel = kwargs.get('cmd_vel', Vector3())
        from geometry_msgs.msg import Vector3
        self.cmd_angular = kwargs.get('cmd_angular', Vector3())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.control_mode != other.control_mode:
            return False
        if self.motion_mode != other.motion_mode:
            return False
        if self.cmd_vel != other.cmd_vel:
            return False
        if self.cmd_angular != other.cmd_angular:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def control_mode(self):
        """Message field 'control_mode'."""
        return self._control_mode

    @control_mode.setter
    def control_mode(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'control_mode' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'control_mode' field must be an unsigned integer in [0, 4294967295]"
        self._control_mode = value

    @builtins.property
    def motion_mode(self):
        """Message field 'motion_mode'."""
        return self._motion_mode

    @motion_mode.setter
    def motion_mode(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'motion_mode' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'motion_mode' field must be an unsigned integer in [0, 4294967295]"
        self._motion_mode = value

    @builtins.property
    def cmd_vel(self):
        """Message field 'cmd_vel'."""
        return self._cmd_vel

    @cmd_vel.setter
    def cmd_vel(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'cmd_vel' field must be a sub message of type 'Vector3'"
        self._cmd_vel = value

    @builtins.property
    def cmd_angular(self):
        """Message field 'cmd_angular'."""
        return self._cmd_angular

    @cmd_angular.setter
    def cmd_angular(self, value):
        if __debug__:
            from geometry_msgs.msg import Vector3
            assert \
                isinstance(value, Vector3), \
                "The 'cmd_angular' field must be a sub message of type 'Vector3'"
        self._cmd_angular = value
