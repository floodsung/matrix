# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(mc_sdk_msg_IDL_FILES "msg/HighLevelCmd.idl;msg/HighLevelRobotState.idl;msg/LowLevelCmd.idl;msg/LowLevelRobotState.idl")
set(mc_sdk_msg_INTERFACE_FILES "msg/HighLevelCmd.msg;msg/HighLevelRobotState.msg;msg/LowLevelCmd.msg;msg/LowLevelRobotState.msg")
