// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__STRUCT_HPP_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__mc_sdk_msg__msg__LowLevelCmd __attribute__((deprecated))
#else
# define DEPRECATED__mc_sdk_msg__msg__LowLevelCmd __declspec(deprecated)
#endif

namespace mc_sdk_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LowLevelCmd_
{
  using Type = LowLevelCmd_<ContainerAllocator>;

  explicit LowLevelCmd_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 12>::iterator, float>(this->q_des.begin(), this->q_des.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->qd_des.begin(), this->qd_des.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->kp.begin(), this->kp.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->kd.begin(), this->kd.end(), 0.0f);
    }
  }

  explicit LowLevelCmd_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : q_des(_alloc),
    qd_des(_alloc),
    kp(_alloc),
    kd(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 12>::iterator, float>(this->q_des.begin(), this->q_des.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->qd_des.begin(), this->qd_des.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->kp.begin(), this->kp.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->kd.begin(), this->kd.end(), 0.0f);
    }
  }

  // field types and members
  using _q_des_type =
    std::array<float, 12>;
  _q_des_type q_des;
  using _qd_des_type =
    std::array<float, 12>;
  _qd_des_type qd_des;
  using _kp_type =
    std::array<float, 12>;
  _kp_type kp;
  using _kd_type =
    std::array<float, 12>;
  _kd_type kd;

  // setters for named parameter idiom
  Type & set__q_des(
    const std::array<float, 12> & _arg)
  {
    this->q_des = _arg;
    return *this;
  }
  Type & set__qd_des(
    const std::array<float, 12> & _arg)
  {
    this->qd_des = _arg;
    return *this;
  }
  Type & set__kp(
    const std::array<float, 12> & _arg)
  {
    this->kp = _arg;
    return *this;
  }
  Type & set__kd(
    const std::array<float, 12> & _arg)
  {
    this->kd = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator> *;
  using ConstRawPtr =
    const mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__mc_sdk_msg__msg__LowLevelCmd
    std::shared_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__mc_sdk_msg__msg__LowLevelCmd
    std::shared_ptr<mc_sdk_msg::msg::LowLevelCmd_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LowLevelCmd_ & other) const
  {
    if (this->q_des != other.q_des) {
      return false;
    }
    if (this->qd_des != other.qd_des) {
      return false;
    }
    if (this->kp != other.kp) {
      return false;
    }
    if (this->kd != other.kd) {
      return false;
    }
    return true;
  }
  bool operator!=(const LowLevelCmd_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LowLevelCmd_

// alias to use template instance with default allocator
using LowLevelCmd =
  mc_sdk_msg::msg::LowLevelCmd_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__STRUCT_HPP_
