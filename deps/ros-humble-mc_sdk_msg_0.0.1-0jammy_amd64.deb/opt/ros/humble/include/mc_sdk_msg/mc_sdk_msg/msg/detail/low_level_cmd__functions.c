// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice
#include "mc_sdk_msg/msg/detail/low_level_cmd__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
mc_sdk_msg__msg__LowLevelCmd__init(mc_sdk_msg__msg__LowLevelCmd * msg)
{
  if (!msg) {
    return false;
  }
  // q_des
  // qd_des
  // kp
  // kd
  return true;
}

void
mc_sdk_msg__msg__LowLevelCmd__fini(mc_sdk_msg__msg__LowLevelCmd * msg)
{
  if (!msg) {
    return;
  }
  // q_des
  // qd_des
  // kp
  // kd
}

bool
mc_sdk_msg__msg__LowLevelCmd__are_equal(const mc_sdk_msg__msg__LowLevelCmd * lhs, const mc_sdk_msg__msg__LowLevelCmd * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // q_des
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->q_des[i] != rhs->q_des[i]) {
      return false;
    }
  }
  // qd_des
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->qd_des[i] != rhs->qd_des[i]) {
      return false;
    }
  }
  // kp
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->kp[i] != rhs->kp[i]) {
      return false;
    }
  }
  // kd
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->kd[i] != rhs->kd[i]) {
      return false;
    }
  }
  return true;
}

bool
mc_sdk_msg__msg__LowLevelCmd__copy(
  const mc_sdk_msg__msg__LowLevelCmd * input,
  mc_sdk_msg__msg__LowLevelCmd * output)
{
  if (!input || !output) {
    return false;
  }
  // q_des
  for (size_t i = 0; i < 12; ++i) {
    output->q_des[i] = input->q_des[i];
  }
  // qd_des
  for (size_t i = 0; i < 12; ++i) {
    output->qd_des[i] = input->qd_des[i];
  }
  // kp
  for (size_t i = 0; i < 12; ++i) {
    output->kp[i] = input->kp[i];
  }
  // kd
  for (size_t i = 0; i < 12; ++i) {
    output->kd[i] = input->kd[i];
  }
  return true;
}

mc_sdk_msg__msg__LowLevelCmd *
mc_sdk_msg__msg__LowLevelCmd__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__LowLevelCmd * msg = (mc_sdk_msg__msg__LowLevelCmd *)allocator.allocate(sizeof(mc_sdk_msg__msg__LowLevelCmd), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(mc_sdk_msg__msg__LowLevelCmd));
  bool success = mc_sdk_msg__msg__LowLevelCmd__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
mc_sdk_msg__msg__LowLevelCmd__destroy(mc_sdk_msg__msg__LowLevelCmd * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    mc_sdk_msg__msg__LowLevelCmd__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
mc_sdk_msg__msg__LowLevelCmd__Sequence__init(mc_sdk_msg__msg__LowLevelCmd__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__LowLevelCmd * data = NULL;

  if (size) {
    data = (mc_sdk_msg__msg__LowLevelCmd *)allocator.zero_allocate(size, sizeof(mc_sdk_msg__msg__LowLevelCmd), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = mc_sdk_msg__msg__LowLevelCmd__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        mc_sdk_msg__msg__LowLevelCmd__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
mc_sdk_msg__msg__LowLevelCmd__Sequence__fini(mc_sdk_msg__msg__LowLevelCmd__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      mc_sdk_msg__msg__LowLevelCmd__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

mc_sdk_msg__msg__LowLevelCmd__Sequence *
mc_sdk_msg__msg__LowLevelCmd__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__LowLevelCmd__Sequence * array = (mc_sdk_msg__msg__LowLevelCmd__Sequence *)allocator.allocate(sizeof(mc_sdk_msg__msg__LowLevelCmd__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = mc_sdk_msg__msg__LowLevelCmd__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
mc_sdk_msg__msg__LowLevelCmd__Sequence__destroy(mc_sdk_msg__msg__LowLevelCmd__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    mc_sdk_msg__msg__LowLevelCmd__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
mc_sdk_msg__msg__LowLevelCmd__Sequence__are_equal(const mc_sdk_msg__msg__LowLevelCmd__Sequence * lhs, const mc_sdk_msg__msg__LowLevelCmd__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!mc_sdk_msg__msg__LowLevelCmd__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
mc_sdk_msg__msg__LowLevelCmd__Sequence__copy(
  const mc_sdk_msg__msg__LowLevelCmd__Sequence * input,
  mc_sdk_msg__msg__LowLevelCmd__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(mc_sdk_msg__msg__LowLevelCmd);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    mc_sdk_msg__msg__LowLevelCmd * data =
      (mc_sdk_msg__msg__LowLevelCmd *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!mc_sdk_msg__msg__LowLevelCmd__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          mc_sdk_msg__msg__LowLevelCmd__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!mc_sdk_msg__msg__LowLevelCmd__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
