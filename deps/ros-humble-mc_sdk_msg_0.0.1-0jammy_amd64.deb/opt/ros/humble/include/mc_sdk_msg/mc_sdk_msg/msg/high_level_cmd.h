// generated from rosidl_generator_c/resource/idl.h.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__HIGH_LEVEL_CMD_H_
#define MC_SDK_MSG__MSG__HIGH_LEVEL_CMD_H_

#include "mc_sdk_msg/msg/detail/high_level_cmd__struct.h"
#include "mc_sdk_msg/msg/detail/high_level_cmd__functions.h"
#include "mc_sdk_msg/msg/detail/high_level_cmd__type_support.h"

#endif  // MC_SDK_MSG__MSG__HIGH_LEVEL_CMD_H_
