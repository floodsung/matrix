// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__BUILDER_HPP_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "mc_sdk_msg/msg/detail/high_level_robot_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace mc_sdk_msg
{

namespace msg
{

namespace builder
{

class Init_HighLevelRobotState_reserved_uint
{
public:
  explicit Init_HighLevelRobotState_reserved_uint(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  ::mc_sdk_msg::msg::HighLevelRobotState reserved_uint(::mc_sdk_msg::msg::HighLevelRobotState::_reserved_uint_type arg)
  {
    msg_.reserved_uint = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_reserved_ft
{
public:
  explicit Init_HighLevelRobotState_reserved_ft(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_reserved_uint reserved_ft(::mc_sdk_msg::msg::HighLevelRobotState::_reserved_ft_type arg)
  {
    msg_.reserved_ft = std::move(arg);
    return Init_HighLevelRobotState_reserved_uint(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_reserved_int
{
public:
  explicit Init_HighLevelRobotState_reserved_int(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_reserved_ft reserved_int(::mc_sdk_msg::msg::HighLevelRobotState::_reserved_int_type arg)
  {
    msg_.reserved_int = std::move(arg);
    return Init_HighLevelRobotState_reserved_ft(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_qd
{
public:
  explicit Init_HighLevelRobotState_qd(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_reserved_int qd(::mc_sdk_msg::msg::HighLevelRobotState::_qd_type arg)
  {
    msg_.qd = std::move(arg);
    return Init_HighLevelRobotState_reserved_int(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_q
{
public:
  explicit Init_HighLevelRobotState_q(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_qd q(::mc_sdk_msg::msg::HighLevelRobotState::_q_type arg)
  {
    msg_.q = std::move(arg);
    return Init_HighLevelRobotState_qd(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_gyro
{
public:
  explicit Init_HighLevelRobotState_gyro(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_q gyro(::mc_sdk_msg::msg::HighLevelRobotState::_gyro_type arg)
  {
    msg_.gyro = std::move(arg);
    return Init_HighLevelRobotState_q(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_acc
{
public:
  explicit Init_HighLevelRobotState_acc(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_gyro acc(::mc_sdk_msg::msg::HighLevelRobotState::_acc_type arg)
  {
    msg_.acc = std::move(arg);
    return Init_HighLevelRobotState_gyro(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_vel
{
public:
  explicit Init_HighLevelRobotState_vel(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_acc vel(::mc_sdk_msg::msg::HighLevelRobotState::_vel_type arg)
  {
    msg_.vel = std::move(arg);
    return Init_HighLevelRobotState_acc(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_rpy
{
public:
  explicit Init_HighLevelRobotState_rpy(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_vel rpy(::mc_sdk_msg::msg::HighLevelRobotState::_rpy_type arg)
  {
    msg_.rpy = std::move(arg);
    return Init_HighLevelRobotState_vel(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_vel_world
{
public:
  explicit Init_HighLevelRobotState_vel_world(::mc_sdk_msg::msg::HighLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_HighLevelRobotState_rpy vel_world(::mc_sdk_msg::msg::HighLevelRobotState::_vel_world_type arg)
  {
    msg_.vel_world = std::move(arg);
    return Init_HighLevelRobotState_rpy(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

class Init_HighLevelRobotState_pos
{
public:
  Init_HighLevelRobotState_pos()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HighLevelRobotState_vel_world pos(::mc_sdk_msg::msg::HighLevelRobotState::_pos_type arg)
  {
    msg_.pos = std::move(arg);
    return Init_HighLevelRobotState_vel_world(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelRobotState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::mc_sdk_msg::msg::HighLevelRobotState>()
{
  return mc_sdk_msg::msg::builder::Init_HighLevelRobotState_pos();
}

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__BUILDER_HPP_
