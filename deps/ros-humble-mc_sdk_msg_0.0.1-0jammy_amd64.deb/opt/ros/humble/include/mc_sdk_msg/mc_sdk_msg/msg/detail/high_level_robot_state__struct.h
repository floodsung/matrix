// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__STRUCT_H_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pos'
// Member 'vel_world'
// Member 'rpy'
// Member 'vel'
// Member 'acc'
// Member 'gyro'
#include "geometry_msgs/msg/detail/vector3__struct.h"
// Member 'reserved_int'
// Member 'reserved_ft'
// Member 'reserved_uint'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/HighLevelRobotState in the package mc_sdk_msg.
typedef struct mc_sdk_msg__msg__HighLevelRobotState
{
  /// Position (x, y, z) in map coordinates (m)
  geometry_msgs__msg__Vector3 pos;
  /// Linear velocity (m/s)
  geometry_msgs__msg__Vector3 vel_world;
  /// Orientation (roll, pitch, yaw) in radians
  geometry_msgs__msg__Vector3 rpy;
  /// Linear velocity (m/s)
  geometry_msgs__msg__Vector3 vel;
  /// Linear acceleration (m/s^2)
  geometry_msgs__msg__Vector3 acc;
  /// angular velocity (rad/s)
  geometry_msgs__msg__Vector3 gyro;
  float q[12];
  float qd[12];
  rosidl_runtime_c__int32__Sequence reserved_int;
  rosidl_runtime_c__double__Sequence reserved_ft;
  rosidl_runtime_c__uint32__Sequence reserved_uint;
} mc_sdk_msg__msg__HighLevelRobotState;

// Struct for a sequence of mc_sdk_msg__msg__HighLevelRobotState.
typedef struct mc_sdk_msg__msg__HighLevelRobotState__Sequence
{
  mc_sdk_msg__msg__HighLevelRobotState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} mc_sdk_msg__msg__HighLevelRobotState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__STRUCT_H_
