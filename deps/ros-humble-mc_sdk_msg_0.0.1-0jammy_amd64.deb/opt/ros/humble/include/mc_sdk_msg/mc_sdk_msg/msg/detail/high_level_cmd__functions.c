// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice
#include "mc_sdk_msg/msg/detail/high_level_cmd__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `cmd_vel`
// Member `cmd_angular`
#include "geometry_msgs/msg/detail/vector3__functions.h"

bool
mc_sdk_msg__msg__HighLevelCmd__init(mc_sdk_msg__msg__HighLevelCmd * msg)
{
  if (!msg) {
    return false;
  }
  // control_mode
  // motion_mode
  // cmd_vel
  if (!geometry_msgs__msg__Vector3__init(&msg->cmd_vel)) {
    mc_sdk_msg__msg__HighLevelCmd__fini(msg);
    return false;
  }
  // cmd_angular
  if (!geometry_msgs__msg__Vector3__init(&msg->cmd_angular)) {
    mc_sdk_msg__msg__HighLevelCmd__fini(msg);
    return false;
  }
  return true;
}

void
mc_sdk_msg__msg__HighLevelCmd__fini(mc_sdk_msg__msg__HighLevelCmd * msg)
{
  if (!msg) {
    return;
  }
  // control_mode
  // motion_mode
  // cmd_vel
  geometry_msgs__msg__Vector3__fini(&msg->cmd_vel);
  // cmd_angular
  geometry_msgs__msg__Vector3__fini(&msg->cmd_angular);
}

bool
mc_sdk_msg__msg__HighLevelCmd__are_equal(const mc_sdk_msg__msg__HighLevelCmd * lhs, const mc_sdk_msg__msg__HighLevelCmd * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // control_mode
  if (lhs->control_mode != rhs->control_mode) {
    return false;
  }
  // motion_mode
  if (lhs->motion_mode != rhs->motion_mode) {
    return false;
  }
  // cmd_vel
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->cmd_vel), &(rhs->cmd_vel)))
  {
    return false;
  }
  // cmd_angular
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->cmd_angular), &(rhs->cmd_angular)))
  {
    return false;
  }
  return true;
}

bool
mc_sdk_msg__msg__HighLevelCmd__copy(
  const mc_sdk_msg__msg__HighLevelCmd * input,
  mc_sdk_msg__msg__HighLevelCmd * output)
{
  if (!input || !output) {
    return false;
  }
  // control_mode
  output->control_mode = input->control_mode;
  // motion_mode
  output->motion_mode = input->motion_mode;
  // cmd_vel
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->cmd_vel), &(output->cmd_vel)))
  {
    return false;
  }
  // cmd_angular
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->cmd_angular), &(output->cmd_angular)))
  {
    return false;
  }
  return true;
}

mc_sdk_msg__msg__HighLevelCmd *
mc_sdk_msg__msg__HighLevelCmd__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__HighLevelCmd * msg = (mc_sdk_msg__msg__HighLevelCmd *)allocator.allocate(sizeof(mc_sdk_msg__msg__HighLevelCmd), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(mc_sdk_msg__msg__HighLevelCmd));
  bool success = mc_sdk_msg__msg__HighLevelCmd__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
mc_sdk_msg__msg__HighLevelCmd__destroy(mc_sdk_msg__msg__HighLevelCmd * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    mc_sdk_msg__msg__HighLevelCmd__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
mc_sdk_msg__msg__HighLevelCmd__Sequence__init(mc_sdk_msg__msg__HighLevelCmd__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__HighLevelCmd * data = NULL;

  if (size) {
    data = (mc_sdk_msg__msg__HighLevelCmd *)allocator.zero_allocate(size, sizeof(mc_sdk_msg__msg__HighLevelCmd), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = mc_sdk_msg__msg__HighLevelCmd__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        mc_sdk_msg__msg__HighLevelCmd__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
mc_sdk_msg__msg__HighLevelCmd__Sequence__fini(mc_sdk_msg__msg__HighLevelCmd__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      mc_sdk_msg__msg__HighLevelCmd__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

mc_sdk_msg__msg__HighLevelCmd__Sequence *
mc_sdk_msg__msg__HighLevelCmd__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__HighLevelCmd__Sequence * array = (mc_sdk_msg__msg__HighLevelCmd__Sequence *)allocator.allocate(sizeof(mc_sdk_msg__msg__HighLevelCmd__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = mc_sdk_msg__msg__HighLevelCmd__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
mc_sdk_msg__msg__HighLevelCmd__Sequence__destroy(mc_sdk_msg__msg__HighLevelCmd__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    mc_sdk_msg__msg__HighLevelCmd__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
mc_sdk_msg__msg__HighLevelCmd__Sequence__are_equal(const mc_sdk_msg__msg__HighLevelCmd__Sequence * lhs, const mc_sdk_msg__msg__HighLevelCmd__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!mc_sdk_msg__msg__HighLevelCmd__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
mc_sdk_msg__msg__HighLevelCmd__Sequence__copy(
  const mc_sdk_msg__msg__HighLevelCmd__Sequence * input,
  mc_sdk_msg__msg__HighLevelCmd__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(mc_sdk_msg__msg__HighLevelCmd);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    mc_sdk_msg__msg__HighLevelCmd * data =
      (mc_sdk_msg__msg__HighLevelCmd *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!mc_sdk_msg__msg__HighLevelCmd__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          mc_sdk_msg__msg__HighLevelCmd__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!mc_sdk_msg__msg__HighLevelCmd__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
