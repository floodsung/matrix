// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__STRUCT_H_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'cmd_vel'
// Member 'cmd_angular'
#include "geometry_msgs/msg/detail/vector3__struct.h"

/// Struct defined in msg/HighLevelCmd in the package mc_sdk_msg.
typedef struct mc_sdk_msg__msg__HighLevelCmd
{
  uint32_t control_mode;
  uint32_t motion_mode;
  geometry_msgs__msg__Vector3 cmd_vel;
  geometry_msgs__msg__Vector3 cmd_angular;
} mc_sdk_msg__msg__HighLevelCmd;

// Struct for a sequence of mc_sdk_msg__msg__HighLevelCmd.
typedef struct mc_sdk_msg__msg__HighLevelCmd__Sequence
{
  mc_sdk_msg__msg__HighLevelCmd * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} mc_sdk_msg__msg__HighLevelCmd__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__STRUCT_H_
