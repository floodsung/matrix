// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "mc_sdk_msg/msg/detail/low_level_cmd__rosidl_typesupport_introspection_c.h"
#include "mc_sdk_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "mc_sdk_msg/msg/detail/low_level_cmd__functions.h"
#include "mc_sdk_msg/msg/detail/low_level_cmd__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  mc_sdk_msg__msg__LowLevelCmd__init(message_memory);
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_fini_function(void * message_memory)
{
  mc_sdk_msg__msg__LowLevelCmd__fini(message_memory);
}

size_t mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__q_des(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__q_des(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__q_des(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__q_des(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__q_des(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__q_des(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__q_des(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__qd_des(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__qd_des(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__qd_des(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__qd_des(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__qd_des(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__qd_des(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__qd_des(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__kp(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__kp(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__kp(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__kp(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__kp(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__kp(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__kp(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__kd(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__kd(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__kd(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__kd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__kd(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__kd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__kd(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_member_array[4] = {
  {
    "q_des",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__LowLevelCmd, q_des),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__q_des,  // size() function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__q_des,  // get_const(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__q_des,  // get(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__q_des,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__q_des,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "qd_des",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__LowLevelCmd, qd_des),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__qd_des,  // size() function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__qd_des,  // get_const(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__qd_des,  // get(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__qd_des,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__qd_des,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "kp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__LowLevelCmd, kp),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__kp,  // size() function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__kp,  // get_const(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__kp,  // get(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__kp,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__kp,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "kd",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__LowLevelCmd, kd),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__size_function__LowLevelCmd__kd,  // size() function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_const_function__LowLevelCmd__kd,  // get_const(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__get_function__LowLevelCmd__kd,  // get(index) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__fetch_function__LowLevelCmd__kd,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__assign_function__LowLevelCmd__kd,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_members = {
  "mc_sdk_msg__msg",  // message namespace
  "LowLevelCmd",  // message name
  4,  // number of fields
  sizeof(mc_sdk_msg__msg__LowLevelCmd),
  mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_member_array,  // message members
  mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_init_function,  // function to initialize message memory (memory has to be allocated)
  mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_type_support_handle = {
  0,
  &mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_mc_sdk_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, mc_sdk_msg, msg, LowLevelCmd)() {
  if (!mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_type_support_handle.typesupport_identifier) {
    mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &mc_sdk_msg__msg__LowLevelCmd__rosidl_typesupport_introspection_c__LowLevelCmd_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
