// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from mc_sdk_msg:msg/LowLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__STRUCT_HPP_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__mc_sdk_msg__msg__LowLevelRobotState __attribute__((deprecated))
#else
# define DEPRECATED__mc_sdk_msg__msg__LowLevelRobotState __declspec(deprecated)
#endif

namespace mc_sdk_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct LowLevelRobotState_
{
  using Type = LowLevelRobotState_<ContainerAllocator>;

  explicit LowLevelRobotState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 12>::iterator, float>(this->q.begin(), this->q.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->qd.begin(), this->qd.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->tau_fb.begin(), this->tau_fb.end(), 0.0f);
    }
  }

  explicit LowLevelRobotState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : q(_alloc),
    qd(_alloc),
    tau_fb(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 12>::iterator, float>(this->q.begin(), this->q.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->qd.begin(), this->qd.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->tau_fb.begin(), this->tau_fb.end(), 0.0f);
    }
  }

  // field types and members
  using _q_type =
    std::array<float, 12>;
  _q_type q;
  using _qd_type =
    std::array<float, 12>;
  _qd_type qd;
  using _tau_fb_type =
    std::array<float, 12>;
  _tau_fb_type tau_fb;

  // setters for named parameter idiom
  Type & set__q(
    const std::array<float, 12> & _arg)
  {
    this->q = _arg;
    return *this;
  }
  Type & set__qd(
    const std::array<float, 12> & _arg)
  {
    this->qd = _arg;
    return *this;
  }
  Type & set__tau_fb(
    const std::array<float, 12> & _arg)
  {
    this->tau_fb = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator> *;
  using ConstRawPtr =
    const mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__mc_sdk_msg__msg__LowLevelRobotState
    std::shared_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__mc_sdk_msg__msg__LowLevelRobotState
    std::shared_ptr<mc_sdk_msg::msg::LowLevelRobotState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const LowLevelRobotState_ & other) const
  {
    if (this->q != other.q) {
      return false;
    }
    if (this->qd != other.qd) {
      return false;
    }
    if (this->tau_fb != other.tau_fb) {
      return false;
    }
    return true;
  }
  bool operator!=(const LowLevelRobotState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct LowLevelRobotState_

// alias to use template instance with default allocator
using LowLevelRobotState =
  mc_sdk_msg::msg::LowLevelRobotState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__STRUCT_HPP_
