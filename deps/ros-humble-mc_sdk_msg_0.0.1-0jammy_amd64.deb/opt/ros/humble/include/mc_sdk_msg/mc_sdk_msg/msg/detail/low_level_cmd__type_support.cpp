// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "mc_sdk_msg/msg/detail/low_level_cmd__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace mc_sdk_msg
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void LowLevelCmd_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) mc_sdk_msg::msg::LowLevelCmd(_init);
}

void LowLevelCmd_fini_function(void * message_memory)
{
  auto typed_message = static_cast<mc_sdk_msg::msg::LowLevelCmd *>(message_memory);
  typed_message->~LowLevelCmd();
}

size_t size_function__LowLevelCmd__q_des(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__LowLevelCmd__q_des(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__LowLevelCmd__q_des(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__LowLevelCmd__q_des(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__LowLevelCmd__q_des(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__LowLevelCmd__q_des(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__LowLevelCmd__q_des(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

size_t size_function__LowLevelCmd__qd_des(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__LowLevelCmd__qd_des(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__LowLevelCmd__qd_des(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__LowLevelCmd__qd_des(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__LowLevelCmd__qd_des(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__LowLevelCmd__qd_des(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__LowLevelCmd__qd_des(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

size_t size_function__LowLevelCmd__kp(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__LowLevelCmd__kp(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__LowLevelCmd__kp(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__LowLevelCmd__kp(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__LowLevelCmd__kp(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__LowLevelCmd__kp(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__LowLevelCmd__kp(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

size_t size_function__LowLevelCmd__kd(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__LowLevelCmd__kd(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__LowLevelCmd__kd(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__LowLevelCmd__kd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__LowLevelCmd__kd(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__LowLevelCmd__kd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__LowLevelCmd__kd(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember LowLevelCmd_message_member_array[4] = {
  {
    "q_des",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::LowLevelCmd, q_des),  // bytes offset in struct
    nullptr,  // default value
    size_function__LowLevelCmd__q_des,  // size() function pointer
    get_const_function__LowLevelCmd__q_des,  // get_const(index) function pointer
    get_function__LowLevelCmd__q_des,  // get(index) function pointer
    fetch_function__LowLevelCmd__q_des,  // fetch(index, &value) function pointer
    assign_function__LowLevelCmd__q_des,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "qd_des",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::LowLevelCmd, qd_des),  // bytes offset in struct
    nullptr,  // default value
    size_function__LowLevelCmd__qd_des,  // size() function pointer
    get_const_function__LowLevelCmd__qd_des,  // get_const(index) function pointer
    get_function__LowLevelCmd__qd_des,  // get(index) function pointer
    fetch_function__LowLevelCmd__qd_des,  // fetch(index, &value) function pointer
    assign_function__LowLevelCmd__qd_des,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "kp",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::LowLevelCmd, kp),  // bytes offset in struct
    nullptr,  // default value
    size_function__LowLevelCmd__kp,  // size() function pointer
    get_const_function__LowLevelCmd__kp,  // get_const(index) function pointer
    get_function__LowLevelCmd__kp,  // get(index) function pointer
    fetch_function__LowLevelCmd__kp,  // fetch(index, &value) function pointer
    assign_function__LowLevelCmd__kp,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "kd",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::LowLevelCmd, kd),  // bytes offset in struct
    nullptr,  // default value
    size_function__LowLevelCmd__kd,  // size() function pointer
    get_const_function__LowLevelCmd__kd,  // get_const(index) function pointer
    get_function__LowLevelCmd__kd,  // get(index) function pointer
    fetch_function__LowLevelCmd__kd,  // fetch(index, &value) function pointer
    assign_function__LowLevelCmd__kd,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers LowLevelCmd_message_members = {
  "mc_sdk_msg::msg",  // message namespace
  "LowLevelCmd",  // message name
  4,  // number of fields
  sizeof(mc_sdk_msg::msg::LowLevelCmd),
  LowLevelCmd_message_member_array,  // message members
  LowLevelCmd_init_function,  // function to initialize message memory (memory has to be allocated)
  LowLevelCmd_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t LowLevelCmd_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &LowLevelCmd_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace mc_sdk_msg


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<mc_sdk_msg::msg::LowLevelCmd>()
{
  return &::mc_sdk_msg::msg::rosidl_typesupport_introspection_cpp::LowLevelCmd_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, mc_sdk_msg, msg, LowLevelCmd)() {
  return &::mc_sdk_msg::msg::rosidl_typesupport_introspection_cpp::LowLevelCmd_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
