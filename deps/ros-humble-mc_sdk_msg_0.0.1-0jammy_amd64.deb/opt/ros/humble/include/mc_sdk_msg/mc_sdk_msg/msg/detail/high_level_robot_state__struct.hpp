// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__STRUCT_HPP_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'pos'
// Member 'vel_world'
// Member 'rpy'
// Member 'vel'
// Member 'acc'
// Member 'gyro'
#include "geometry_msgs/msg/detail/vector3__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__mc_sdk_msg__msg__HighLevelRobotState __attribute__((deprecated))
#else
# define DEPRECATED__mc_sdk_msg__msg__HighLevelRobotState __declspec(deprecated)
#endif

namespace mc_sdk_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct HighLevelRobotState_
{
  using Type = HighLevelRobotState_<ContainerAllocator>;

  explicit HighLevelRobotState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pos(_init),
    vel_world(_init),
    rpy(_init),
    vel(_init),
    acc(_init),
    gyro(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 12>::iterator, float>(this->q.begin(), this->q.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->qd.begin(), this->qd.end(), 0.0f);
    }
  }

  explicit HighLevelRobotState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : pos(_alloc, _init),
    vel_world(_alloc, _init),
    rpy(_alloc, _init),
    vel(_alloc, _init),
    acc(_alloc, _init),
    gyro(_alloc, _init),
    q(_alloc),
    qd(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<float, 12>::iterator, float>(this->q.begin(), this->q.end(), 0.0f);
      std::fill<typename std::array<float, 12>::iterator, float>(this->qd.begin(), this->qd.end(), 0.0f);
    }
  }

  // field types and members
  using _pos_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _pos_type pos;
  using _vel_world_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _vel_world_type vel_world;
  using _rpy_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _rpy_type rpy;
  using _vel_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _vel_type vel;
  using _acc_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _acc_type acc;
  using _gyro_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _gyro_type gyro;
  using _q_type =
    std::array<float, 12>;
  _q_type q;
  using _qd_type =
    std::array<float, 12>;
  _qd_type qd;
  using _reserved_int_type =
    std::vector<int32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int32_t>>;
  _reserved_int_type reserved_int;
  using _reserved_ft_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _reserved_ft_type reserved_ft;
  using _reserved_uint_type =
    std::vector<uint32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint32_t>>;
  _reserved_uint_type reserved_uint;

  // setters for named parameter idiom
  Type & set__pos(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->pos = _arg;
    return *this;
  }
  Type & set__vel_world(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->vel_world = _arg;
    return *this;
  }
  Type & set__rpy(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->rpy = _arg;
    return *this;
  }
  Type & set__vel(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->vel = _arg;
    return *this;
  }
  Type & set__acc(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->acc = _arg;
    return *this;
  }
  Type & set__gyro(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->gyro = _arg;
    return *this;
  }
  Type & set__q(
    const std::array<float, 12> & _arg)
  {
    this->q = _arg;
    return *this;
  }
  Type & set__qd(
    const std::array<float, 12> & _arg)
  {
    this->qd = _arg;
    return *this;
  }
  Type & set__reserved_int(
    const std::vector<int32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<int32_t>> & _arg)
  {
    this->reserved_int = _arg;
    return *this;
  }
  Type & set__reserved_ft(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->reserved_ft = _arg;
    return *this;
  }
  Type & set__reserved_uint(
    const std::vector<uint32_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint32_t>> & _arg)
  {
    this->reserved_uint = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator> *;
  using ConstRawPtr =
    const mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__mc_sdk_msg__msg__HighLevelRobotState
    std::shared_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__mc_sdk_msg__msg__HighLevelRobotState
    std::shared_ptr<mc_sdk_msg::msg::HighLevelRobotState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const HighLevelRobotState_ & other) const
  {
    if (this->pos != other.pos) {
      return false;
    }
    if (this->vel_world != other.vel_world) {
      return false;
    }
    if (this->rpy != other.rpy) {
      return false;
    }
    if (this->vel != other.vel) {
      return false;
    }
    if (this->acc != other.acc) {
      return false;
    }
    if (this->gyro != other.gyro) {
      return false;
    }
    if (this->q != other.q) {
      return false;
    }
    if (this->qd != other.qd) {
      return false;
    }
    if (this->reserved_int != other.reserved_int) {
      return false;
    }
    if (this->reserved_ft != other.reserved_ft) {
      return false;
    }
    if (this->reserved_uint != other.reserved_uint) {
      return false;
    }
    return true;
  }
  bool operator!=(const HighLevelRobotState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct HighLevelRobotState_

// alias to use template instance with default allocator
using HighLevelRobotState =
  mc_sdk_msg::msg::HighLevelRobotState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__STRUCT_HPP_
