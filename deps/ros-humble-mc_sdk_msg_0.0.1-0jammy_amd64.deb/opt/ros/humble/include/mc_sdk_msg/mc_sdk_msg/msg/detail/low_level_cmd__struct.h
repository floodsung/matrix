﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__STRUCT_H_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/LowLevelCmd in the package mc_sdk_msg.
/**
  * 电机关节角度指令 (单位: rad)
 */
typedef struct mc_sdk_msg__msg__LowLevelCmd
{
  float q_des[12];
  /// 电机关节角速度指令 (单位: rad/s)
  float qd_des[12];
  /// 电机控制增益
  float kp[12];
  float kd[12];
} mc_sdk_msg__msg__LowLevelCmd;

// Struct for a sequence of mc_sdk_msg__msg__LowLevelCmd.
typedef struct mc_sdk_msg__msg__LowLevelCmd__Sequence
{
  mc_sdk_msg__msg__LowLevelCmd * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} mc_sdk_msg__msg__LowLevelCmd__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__STRUCT_H_
