// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__FUNCTIONS_H_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "mc_sdk_msg/msg/rosidl_generator_c__visibility_control.h"

#include "mc_sdk_msg/msg/detail/high_level_cmd__struct.h"

/// Initialize msg/HighLevelCmd message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * mc_sdk_msg__msg__HighLevelCmd
 * )) before or use
 * mc_sdk_msg__msg__HighLevelCmd__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
bool
mc_sdk_msg__msg__HighLevelCmd__init(mc_sdk_msg__msg__HighLevelCmd * msg);

/// Finalize msg/HighLevelCmd message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
void
mc_sdk_msg__msg__HighLevelCmd__fini(mc_sdk_msg__msg__HighLevelCmd * msg);

/// Create msg/HighLevelCmd message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * mc_sdk_msg__msg__HighLevelCmd__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
mc_sdk_msg__msg__HighLevelCmd *
mc_sdk_msg__msg__HighLevelCmd__create();

/// Destroy msg/HighLevelCmd message.
/**
 * It calls
 * mc_sdk_msg__msg__HighLevelCmd__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
void
mc_sdk_msg__msg__HighLevelCmd__destroy(mc_sdk_msg__msg__HighLevelCmd * msg);

/// Check for msg/HighLevelCmd message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
bool
mc_sdk_msg__msg__HighLevelCmd__are_equal(const mc_sdk_msg__msg__HighLevelCmd * lhs, const mc_sdk_msg__msg__HighLevelCmd * rhs);

/// Copy a msg/HighLevelCmd message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
bool
mc_sdk_msg__msg__HighLevelCmd__copy(
  const mc_sdk_msg__msg__HighLevelCmd * input,
  mc_sdk_msg__msg__HighLevelCmd * output);

/// Initialize array of msg/HighLevelCmd messages.
/**
 * It allocates the memory for the number of elements and calls
 * mc_sdk_msg__msg__HighLevelCmd__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
bool
mc_sdk_msg__msg__HighLevelCmd__Sequence__init(mc_sdk_msg__msg__HighLevelCmd__Sequence * array, size_t size);

/// Finalize array of msg/HighLevelCmd messages.
/**
 * It calls
 * mc_sdk_msg__msg__HighLevelCmd__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
void
mc_sdk_msg__msg__HighLevelCmd__Sequence__fini(mc_sdk_msg__msg__HighLevelCmd__Sequence * array);

/// Create array of msg/HighLevelCmd messages.
/**
 * It allocates the memory for the array and calls
 * mc_sdk_msg__msg__HighLevelCmd__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
mc_sdk_msg__msg__HighLevelCmd__Sequence *
mc_sdk_msg__msg__HighLevelCmd__Sequence__create(size_t size);

/// Destroy array of msg/HighLevelCmd messages.
/**
 * It calls
 * mc_sdk_msg__msg__HighLevelCmd__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
void
mc_sdk_msg__msg__HighLevelCmd__Sequence__destroy(mc_sdk_msg__msg__HighLevelCmd__Sequence * array);

/// Check for msg/HighLevelCmd message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
bool
mc_sdk_msg__msg__HighLevelCmd__Sequence__are_equal(const mc_sdk_msg__msg__HighLevelCmd__Sequence * lhs, const mc_sdk_msg__msg__HighLevelCmd__Sequence * rhs);

/// Copy an array of msg/HighLevelCmd messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_mc_sdk_msg
bool
mc_sdk_msg__msg__HighLevelCmd__Sequence__copy(
  const mc_sdk_msg__msg__HighLevelCmd__Sequence * input,
  mc_sdk_msg__msg__HighLevelCmd__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__FUNCTIONS_H_
