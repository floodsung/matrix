// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "mc_sdk_msg/msg/detail/high_level_cmd__rosidl_typesupport_introspection_c.h"
#include "mc_sdk_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "mc_sdk_msg/msg/detail/high_level_cmd__functions.h"
#include "mc_sdk_msg/msg/detail/high_level_cmd__struct.h"


// Include directives for member types
// Member `cmd_vel`
// Member `cmd_angular`
#include "geometry_msgs/msg/vector3.h"
// Member `cmd_vel`
// Member `cmd_angular`
#include "geometry_msgs/msg/detail/vector3__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  mc_sdk_msg__msg__HighLevelCmd__init(message_memory);
}

void mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_fini_function(void * message_memory)
{
  mc_sdk_msg__msg__HighLevelCmd__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_member_array[4] = {
  {
    "control_mode",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelCmd, control_mode),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_mode",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelCmd, motion_mode),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "cmd_vel",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelCmd, cmd_vel),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "cmd_angular",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelCmd, cmd_angular),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_members = {
  "mc_sdk_msg__msg",  // message namespace
  "HighLevelCmd",  // message name
  4,  // number of fields
  sizeof(mc_sdk_msg__msg__HighLevelCmd),
  mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_member_array,  // message members
  mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_init_function,  // function to initialize message memory (memory has to be allocated)
  mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_type_support_handle = {
  0,
  &mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_mc_sdk_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, mc_sdk_msg, msg, HighLevelCmd)() {
  mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  if (!mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_type_support_handle.typesupport_identifier) {
    mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &mc_sdk_msg__msg__HighLevelCmd__rosidl_typesupport_introspection_c__HighLevelCmd_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
