// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__STRUCT_HPP_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'cmd_vel'
// Member 'cmd_angular'
#include "geometry_msgs/msg/detail/vector3__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__mc_sdk_msg__msg__HighLevelCmd __attribute__((deprecated))
#else
# define DEPRECATED__mc_sdk_msg__msg__HighLevelCmd __declspec(deprecated)
#endif

namespace mc_sdk_msg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct HighLevelCmd_
{
  using Type = HighLevelCmd_<ContainerAllocator>;

  explicit HighLevelCmd_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : cmd_vel(_init),
    cmd_angular(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->control_mode = 0ul;
      this->motion_mode = 0ul;
    }
  }

  explicit HighLevelCmd_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : cmd_vel(_alloc, _init),
    cmd_angular(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->control_mode = 0ul;
      this->motion_mode = 0ul;
    }
  }

  // field types and members
  using _control_mode_type =
    uint32_t;
  _control_mode_type control_mode;
  using _motion_mode_type =
    uint32_t;
  _motion_mode_type motion_mode;
  using _cmd_vel_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _cmd_vel_type cmd_vel;
  using _cmd_angular_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _cmd_angular_type cmd_angular;

  // setters for named parameter idiom
  Type & set__control_mode(
    const uint32_t & _arg)
  {
    this->control_mode = _arg;
    return *this;
  }
  Type & set__motion_mode(
    const uint32_t & _arg)
  {
    this->motion_mode = _arg;
    return *this;
  }
  Type & set__cmd_vel(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->cmd_vel = _arg;
    return *this;
  }
  Type & set__cmd_angular(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->cmd_angular = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator> *;
  using ConstRawPtr =
    const mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__mc_sdk_msg__msg__HighLevelCmd
    std::shared_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__mc_sdk_msg__msg__HighLevelCmd
    std::shared_ptr<mc_sdk_msg::msg::HighLevelCmd_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const HighLevelCmd_ & other) const
  {
    if (this->control_mode != other.control_mode) {
      return false;
    }
    if (this->motion_mode != other.motion_mode) {
      return false;
    }
    if (this->cmd_vel != other.cmd_vel) {
      return false;
    }
    if (this->cmd_angular != other.cmd_angular) {
      return false;
    }
    return true;
  }
  bool operator!=(const HighLevelCmd_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct HighLevelCmd_

// alias to use template instance with default allocator
using HighLevelCmd =
  mc_sdk_msg::msg::HighLevelCmd_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__STRUCT_HPP_
