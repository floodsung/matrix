// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__BUILDER_HPP_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "mc_sdk_msg/msg/detail/low_level_cmd__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace mc_sdk_msg
{

namespace msg
{

namespace builder
{

class Init_LowLevelCmd_kd
{
public:
  explicit Init_LowLevelCmd_kd(::mc_sdk_msg::msg::LowLevelCmd & msg)
  : msg_(msg)
  {}
  ::mc_sdk_msg::msg::LowLevelCmd kd(::mc_sdk_msg::msg::LowLevelCmd::_kd_type arg)
  {
    msg_.kd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mc_sdk_msg::msg::LowLevelCmd msg_;
};

class Init_LowLevelCmd_kp
{
public:
  explicit Init_LowLevelCmd_kp(::mc_sdk_msg::msg::LowLevelCmd & msg)
  : msg_(msg)
  {}
  Init_LowLevelCmd_kd kp(::mc_sdk_msg::msg::LowLevelCmd::_kp_type arg)
  {
    msg_.kp = std::move(arg);
    return Init_LowLevelCmd_kd(msg_);
  }

private:
  ::mc_sdk_msg::msg::LowLevelCmd msg_;
};

class Init_LowLevelCmd_qd_des
{
public:
  explicit Init_LowLevelCmd_qd_des(::mc_sdk_msg::msg::LowLevelCmd & msg)
  : msg_(msg)
  {}
  Init_LowLevelCmd_kp qd_des(::mc_sdk_msg::msg::LowLevelCmd::_qd_des_type arg)
  {
    msg_.qd_des = std::move(arg);
    return Init_LowLevelCmd_kp(msg_);
  }

private:
  ::mc_sdk_msg::msg::LowLevelCmd msg_;
};

class Init_LowLevelCmd_q_des
{
public:
  Init_LowLevelCmd_q_des()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LowLevelCmd_qd_des q_des(::mc_sdk_msg::msg::LowLevelCmd::_q_des_type arg)
  {
    msg_.q_des = std::move(arg);
    return Init_LowLevelCmd_qd_des(msg_);
  }

private:
  ::mc_sdk_msg::msg::LowLevelCmd msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::mc_sdk_msg::msg::LowLevelCmd>()
{
  return mc_sdk_msg::msg::builder::Init_LowLevelCmd_q_des();
}

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__BUILDER_HPP_
