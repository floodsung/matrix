// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__TRAITS_HPP_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "mc_sdk_msg/msg/detail/high_level_cmd__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'cmd_vel'
// Member 'cmd_angular'
#include "geometry_msgs/msg/detail/vector3__traits.hpp"

namespace mc_sdk_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const HighLevelCmd & msg,
  std::ostream & out)
{
  out << "{";
  // member: control_mode
  {
    out << "control_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.control_mode, out);
    out << ", ";
  }

  // member: motion_mode
  {
    out << "motion_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_mode, out);
    out << ", ";
  }

  // member: cmd_vel
  {
    out << "cmd_vel: ";
    to_flow_style_yaml(msg.cmd_vel, out);
    out << ", ";
  }

  // member: cmd_angular
  {
    out << "cmd_angular: ";
    to_flow_style_yaml(msg.cmd_angular, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HighLevelCmd & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: control_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "control_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.control_mode, out);
    out << "\n";
  }

  // member: motion_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.motion_mode, out);
    out << "\n";
  }

  // member: cmd_vel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_vel:\n";
    to_block_style_yaml(msg.cmd_vel, out, indentation + 2);
  }

  // member: cmd_angular
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cmd_angular:\n";
    to_block_style_yaml(msg.cmd_angular, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HighLevelCmd & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace mc_sdk_msg

namespace rosidl_generator_traits
{

[[deprecated("use mc_sdk_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const mc_sdk_msg::msg::HighLevelCmd & msg,
  std::ostream & out, size_t indentation = 0)
{
  mc_sdk_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use mc_sdk_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const mc_sdk_msg::msg::HighLevelCmd & msg)
{
  return mc_sdk_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<mc_sdk_msg::msg::HighLevelCmd>()
{
  return "mc_sdk_msg::msg::HighLevelCmd";
}

template<>
inline const char * name<mc_sdk_msg::msg::HighLevelCmd>()
{
  return "mc_sdk_msg/msg/HighLevelCmd";
}

template<>
struct has_fixed_size<mc_sdk_msg::msg::HighLevelCmd>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Vector3>::value> {};

template<>
struct has_bounded_size<mc_sdk_msg::msg::HighLevelCmd>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Vector3>::value> {};

template<>
struct is_message<mc_sdk_msg::msg::HighLevelCmd>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__TRAITS_HPP_
