// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__HIGH_LEVEL_CMD_HPP_
#define MC_SDK_MSG__MSG__HIGH_LEVEL_CMD_HPP_

#include "mc_sdk_msg/msg/detail/high_level_cmd__struct.hpp"
#include "mc_sdk_msg/msg/detail/high_level_cmd__builder.hpp"
#include "mc_sdk_msg/msg/detail/high_level_cmd__traits.hpp"
#include "mc_sdk_msg/msg/detail/high_level_cmd__type_support.hpp"

#endif  // MC_SDK_MSG__MSG__HIGH_LEVEL_CMD_HPP_
