// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "mc_sdk_msg/msg/detail/high_level_robot_state__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace mc_sdk_msg
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void HighLevelRobotState_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) mc_sdk_msg::msg::HighLevelRobotState(_init);
}

void HighLevelRobotState_fini_function(void * message_memory)
{
  auto typed_message = static_cast<mc_sdk_msg::msg::HighLevelRobotState *>(message_memory);
  typed_message->~HighLevelRobotState();
}

size_t size_function__HighLevelRobotState__q(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__HighLevelRobotState__q(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__HighLevelRobotState__q(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__HighLevelRobotState__q(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__HighLevelRobotState__q(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__HighLevelRobotState__q(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__HighLevelRobotState__q(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

size_t size_function__HighLevelRobotState__qd(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__HighLevelRobotState__qd(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__HighLevelRobotState__qd(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__HighLevelRobotState__qd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__HighLevelRobotState__qd(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__HighLevelRobotState__qd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__HighLevelRobotState__qd(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

size_t size_function__HighLevelRobotState__reserved_int(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<int32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__HighLevelRobotState__reserved_int(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<int32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__HighLevelRobotState__reserved_int(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<int32_t> *>(untyped_member);
  return &member[index];
}

void fetch_function__HighLevelRobotState__reserved_int(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const int32_t *>(
    get_const_function__HighLevelRobotState__reserved_int(untyped_member, index));
  auto & value = *reinterpret_cast<int32_t *>(untyped_value);
  value = item;
}

void assign_function__HighLevelRobotState__reserved_int(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<int32_t *>(
    get_function__HighLevelRobotState__reserved_int(untyped_member, index));
  const auto & value = *reinterpret_cast<const int32_t *>(untyped_value);
  item = value;
}

void resize_function__HighLevelRobotState__reserved_int(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<int32_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__HighLevelRobotState__reserved_ft(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<double> *>(untyped_member);
  return member->size();
}

const void * get_const_function__HighLevelRobotState__reserved_ft(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<double> *>(untyped_member);
  return &member[index];
}

void * get_function__HighLevelRobotState__reserved_ft(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<double> *>(untyped_member);
  return &member[index];
}

void fetch_function__HighLevelRobotState__reserved_ft(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const double *>(
    get_const_function__HighLevelRobotState__reserved_ft(untyped_member, index));
  auto & value = *reinterpret_cast<double *>(untyped_value);
  value = item;
}

void assign_function__HighLevelRobotState__reserved_ft(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<double *>(
    get_function__HighLevelRobotState__reserved_ft(untyped_member, index));
  const auto & value = *reinterpret_cast<const double *>(untyped_value);
  item = value;
}

void resize_function__HighLevelRobotState__reserved_ft(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<double> *>(untyped_member);
  member->resize(size);
}

size_t size_function__HighLevelRobotState__reserved_uint(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__HighLevelRobotState__reserved_uint(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__HighLevelRobotState__reserved_uint(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void fetch_function__HighLevelRobotState__reserved_uint(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint32_t *>(
    get_const_function__HighLevelRobotState__reserved_uint(untyped_member, index));
  auto & value = *reinterpret_cast<uint32_t *>(untyped_value);
  value = item;
}

void assign_function__HighLevelRobotState__reserved_uint(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint32_t *>(
    get_function__HighLevelRobotState__reserved_uint(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint32_t *>(untyped_value);
  item = value;
}

void resize_function__HighLevelRobotState__reserved_uint(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember HighLevelRobotState_message_member_array[11] = {
  {
    "pos",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<geometry_msgs::msg::Vector3>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, pos),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "vel_world",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<geometry_msgs::msg::Vector3>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, vel_world),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "rpy",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<geometry_msgs::msg::Vector3>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, rpy),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "vel",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<geometry_msgs::msg::Vector3>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, vel),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "acc",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<geometry_msgs::msg::Vector3>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, acc),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "gyro",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<geometry_msgs::msg::Vector3>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, gyro),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "q",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, q),  // bytes offset in struct
    nullptr,  // default value
    size_function__HighLevelRobotState__q,  // size() function pointer
    get_const_function__HighLevelRobotState__q,  // get_const(index) function pointer
    get_function__HighLevelRobotState__q,  // get(index) function pointer
    fetch_function__HighLevelRobotState__q,  // fetch(index, &value) function pointer
    assign_function__HighLevelRobotState__q,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "qd",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, qd),  // bytes offset in struct
    nullptr,  // default value
    size_function__HighLevelRobotState__qd,  // size() function pointer
    get_const_function__HighLevelRobotState__qd,  // get_const(index) function pointer
    get_function__HighLevelRobotState__qd,  // get(index) function pointer
    fetch_function__HighLevelRobotState__qd,  // fetch(index, &value) function pointer
    assign_function__HighLevelRobotState__qd,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "reserved_int",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, reserved_int),  // bytes offset in struct
    nullptr,  // default value
    size_function__HighLevelRobotState__reserved_int,  // size() function pointer
    get_const_function__HighLevelRobotState__reserved_int,  // get_const(index) function pointer
    get_function__HighLevelRobotState__reserved_int,  // get(index) function pointer
    fetch_function__HighLevelRobotState__reserved_int,  // fetch(index, &value) function pointer
    assign_function__HighLevelRobotState__reserved_int,  // assign(index, value) function pointer
    resize_function__HighLevelRobotState__reserved_int  // resize(index) function pointer
  },
  {
    "reserved_ft",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, reserved_ft),  // bytes offset in struct
    nullptr,  // default value
    size_function__HighLevelRobotState__reserved_ft,  // size() function pointer
    get_const_function__HighLevelRobotState__reserved_ft,  // get_const(index) function pointer
    get_function__HighLevelRobotState__reserved_ft,  // get(index) function pointer
    fetch_function__HighLevelRobotState__reserved_ft,  // fetch(index, &value) function pointer
    assign_function__HighLevelRobotState__reserved_ft,  // assign(index, value) function pointer
    resize_function__HighLevelRobotState__reserved_ft  // resize(index) function pointer
  },
  {
    "reserved_uint",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::HighLevelRobotState, reserved_uint),  // bytes offset in struct
    nullptr,  // default value
    size_function__HighLevelRobotState__reserved_uint,  // size() function pointer
    get_const_function__HighLevelRobotState__reserved_uint,  // get_const(index) function pointer
    get_function__HighLevelRobotState__reserved_uint,  // get(index) function pointer
    fetch_function__HighLevelRobotState__reserved_uint,  // fetch(index, &value) function pointer
    assign_function__HighLevelRobotState__reserved_uint,  // assign(index, value) function pointer
    resize_function__HighLevelRobotState__reserved_uint  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers HighLevelRobotState_message_members = {
  "mc_sdk_msg::msg",  // message namespace
  "HighLevelRobotState",  // message name
  11,  // number of fields
  sizeof(mc_sdk_msg::msg::HighLevelRobotState),
  HighLevelRobotState_message_member_array,  // message members
  HighLevelRobotState_init_function,  // function to initialize message memory (memory has to be allocated)
  HighLevelRobotState_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t HighLevelRobotState_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &HighLevelRobotState_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace mc_sdk_msg


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<mc_sdk_msg::msg::HighLevelRobotState>()
{
  return &::mc_sdk_msg::msg::rosidl_typesupport_introspection_cpp::HighLevelRobotState_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, mc_sdk_msg, msg, HighLevelRobotState)() {
  return &::mc_sdk_msg::msg::rosidl_typesupport_introspection_cpp::HighLevelRobotState_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
