﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from mc_sdk_msg:msg/LowLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__STRUCT_H_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/LowLevelRobotState in the package mc_sdk_msg.
/**
  * 电机关节角度反馈 (单位: rad)
 */
typedef struct mc_sdk_msg__msg__LowLevelRobotState
{
  float q[12];
  /// 电机关节角速度反馈 (单位: rad/s)
  float qd[12];
  /// 电机关节力矩反馈 (单位: Nm)
  float tau_fb[12];
} mc_sdk_msg__msg__LowLevelRobotState;

// Struct for a sequence of mc_sdk_msg__msg__LowLevelRobotState.
typedef struct mc_sdk_msg__msg__LowLevelRobotState__Sequence
{
  mc_sdk_msg__msg__LowLevelRobotState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} mc_sdk_msg__msg__LowLevelRobotState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__STRUCT_H_
