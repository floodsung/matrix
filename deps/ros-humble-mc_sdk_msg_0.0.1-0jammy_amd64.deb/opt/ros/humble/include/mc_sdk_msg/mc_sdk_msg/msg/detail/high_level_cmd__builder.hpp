// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from mc_sdk_msg:msg/HighLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__BUILDER_HPP_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "mc_sdk_msg/msg/detail/high_level_cmd__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace mc_sdk_msg
{

namespace msg
{

namespace builder
{

class Init_HighLevelCmd_cmd_angular
{
public:
  explicit Init_HighLevelCmd_cmd_angular(::mc_sdk_msg::msg::HighLevelCmd & msg)
  : msg_(msg)
  {}
  ::mc_sdk_msg::msg::HighLevelCmd cmd_angular(::mc_sdk_msg::msg::HighLevelCmd::_cmd_angular_type arg)
  {
    msg_.cmd_angular = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelCmd msg_;
};

class Init_HighLevelCmd_cmd_vel
{
public:
  explicit Init_HighLevelCmd_cmd_vel(::mc_sdk_msg::msg::HighLevelCmd & msg)
  : msg_(msg)
  {}
  Init_HighLevelCmd_cmd_angular cmd_vel(::mc_sdk_msg::msg::HighLevelCmd::_cmd_vel_type arg)
  {
    msg_.cmd_vel = std::move(arg);
    return Init_HighLevelCmd_cmd_angular(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelCmd msg_;
};

class Init_HighLevelCmd_motion_mode
{
public:
  explicit Init_HighLevelCmd_motion_mode(::mc_sdk_msg::msg::HighLevelCmd & msg)
  : msg_(msg)
  {}
  Init_HighLevelCmd_cmd_vel motion_mode(::mc_sdk_msg::msg::HighLevelCmd::_motion_mode_type arg)
  {
    msg_.motion_mode = std::move(arg);
    return Init_HighLevelCmd_cmd_vel(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelCmd msg_;
};

class Init_HighLevelCmd_control_mode
{
public:
  Init_HighLevelCmd_control_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HighLevelCmd_motion_mode control_mode(::mc_sdk_msg::msg::HighLevelCmd::_control_mode_type arg)
  {
    msg_.control_mode = std::move(arg);
    return Init_HighLevelCmd_motion_mode(msg_);
  }

private:
  ::mc_sdk_msg::msg::HighLevelCmd msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::mc_sdk_msg::msg::HighLevelCmd>()
{
  return mc_sdk_msg::msg::builder::Init_HighLevelCmd_control_mode();
}

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_CMD__BUILDER_HPP_
