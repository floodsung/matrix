// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from mc_sdk_msg:msg/LowLevelRobotState.idl
// generated code does not contain a copyright notice
#include "mc_sdk_msg/msg/detail/low_level_robot_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
mc_sdk_msg__msg__LowLevelRobotState__init(mc_sdk_msg__msg__LowLevelRobotState * msg)
{
  if (!msg) {
    return false;
  }
  // q
  // qd
  // tau_fb
  return true;
}

void
mc_sdk_msg__msg__LowLevelRobotState__fini(mc_sdk_msg__msg__LowLevelRobotState * msg)
{
  if (!msg) {
    return;
  }
  // q
  // qd
  // tau_fb
}

bool
mc_sdk_msg__msg__LowLevelRobotState__are_equal(const mc_sdk_msg__msg__LowLevelRobotState * lhs, const mc_sdk_msg__msg__LowLevelRobotState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // q
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->q[i] != rhs->q[i]) {
      return false;
    }
  }
  // qd
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->qd[i] != rhs->qd[i]) {
      return false;
    }
  }
  // tau_fb
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->tau_fb[i] != rhs->tau_fb[i]) {
      return false;
    }
  }
  return true;
}

bool
mc_sdk_msg__msg__LowLevelRobotState__copy(
  const mc_sdk_msg__msg__LowLevelRobotState * input,
  mc_sdk_msg__msg__LowLevelRobotState * output)
{
  if (!input || !output) {
    return false;
  }
  // q
  for (size_t i = 0; i < 12; ++i) {
    output->q[i] = input->q[i];
  }
  // qd
  for (size_t i = 0; i < 12; ++i) {
    output->qd[i] = input->qd[i];
  }
  // tau_fb
  for (size_t i = 0; i < 12; ++i) {
    output->tau_fb[i] = input->tau_fb[i];
  }
  return true;
}

mc_sdk_msg__msg__LowLevelRobotState *
mc_sdk_msg__msg__LowLevelRobotState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__LowLevelRobotState * msg = (mc_sdk_msg__msg__LowLevelRobotState *)allocator.allocate(sizeof(mc_sdk_msg__msg__LowLevelRobotState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(mc_sdk_msg__msg__LowLevelRobotState));
  bool success = mc_sdk_msg__msg__LowLevelRobotState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
mc_sdk_msg__msg__LowLevelRobotState__destroy(mc_sdk_msg__msg__LowLevelRobotState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    mc_sdk_msg__msg__LowLevelRobotState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
mc_sdk_msg__msg__LowLevelRobotState__Sequence__init(mc_sdk_msg__msg__LowLevelRobotState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__LowLevelRobotState * data = NULL;

  if (size) {
    data = (mc_sdk_msg__msg__LowLevelRobotState *)allocator.zero_allocate(size, sizeof(mc_sdk_msg__msg__LowLevelRobotState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = mc_sdk_msg__msg__LowLevelRobotState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        mc_sdk_msg__msg__LowLevelRobotState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
mc_sdk_msg__msg__LowLevelRobotState__Sequence__fini(mc_sdk_msg__msg__LowLevelRobotState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      mc_sdk_msg__msg__LowLevelRobotState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

mc_sdk_msg__msg__LowLevelRobotState__Sequence *
mc_sdk_msg__msg__LowLevelRobotState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__LowLevelRobotState__Sequence * array = (mc_sdk_msg__msg__LowLevelRobotState__Sequence *)allocator.allocate(sizeof(mc_sdk_msg__msg__LowLevelRobotState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = mc_sdk_msg__msg__LowLevelRobotState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
mc_sdk_msg__msg__LowLevelRobotState__Sequence__destroy(mc_sdk_msg__msg__LowLevelRobotState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    mc_sdk_msg__msg__LowLevelRobotState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
mc_sdk_msg__msg__LowLevelRobotState__Sequence__are_equal(const mc_sdk_msg__msg__LowLevelRobotState__Sequence * lhs, const mc_sdk_msg__msg__LowLevelRobotState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!mc_sdk_msg__msg__LowLevelRobotState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
mc_sdk_msg__msg__LowLevelRobotState__Sequence__copy(
  const mc_sdk_msg__msg__LowLevelRobotState__Sequence * input,
  mc_sdk_msg__msg__LowLevelRobotState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(mc_sdk_msg__msg__LowLevelRobotState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    mc_sdk_msg__msg__LowLevelRobotState * data =
      (mc_sdk_msg__msg__LowLevelRobotState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!mc_sdk_msg__msg__LowLevelRobotState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          mc_sdk_msg__msg__LowLevelRobotState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!mc_sdk_msg__msg__LowLevelRobotState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
