// generated from rosidl_typesupport_fastrtps_cpp/resource/idl__rosidl_typesupport_fastrtps_cpp.hpp.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "mc_sdk_msg/msg/rosidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "mc_sdk_msg/msg/detail/low_level_cmd__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace mc_sdk_msg
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_mc_sdk_msg
cdr_serialize(
  const mc_sdk_msg::msg::LowLevelCmd & ros_message,
  eprosima::fastcdr::Cdr & cdr);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_mc_sdk_msg
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  mc_sdk_msg::msg::LowLevelCmd & ros_message);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_mc_sdk_msg
get_serialized_size(
  const mc_sdk_msg::msg::LowLevelCmd & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_mc_sdk_msg
max_serialized_size_LowLevelCmd(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace mc_sdk_msg

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_mc_sdk_msg
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_cpp, mc_sdk_msg, msg, LowLevelCmd)();

#ifdef __cplusplus
}
#endif

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
