// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__TYPE_SUPPORT_HPP_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "mc_sdk_msg/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_mc_sdk_msg
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  mc_sdk_msg,
  msg,
  HighLevelRobotState
)();
#ifdef __cplusplus
}
#endif

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__TYPE_SUPPORT_HPP_
