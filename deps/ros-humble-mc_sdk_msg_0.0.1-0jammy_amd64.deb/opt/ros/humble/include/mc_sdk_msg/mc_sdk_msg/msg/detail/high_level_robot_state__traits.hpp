// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__TRAITS_HPP_
#define MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "mc_sdk_msg/msg/detail/high_level_robot_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'pos'
// Member 'vel_world'
// Member 'rpy'
// Member 'vel'
// Member 'acc'
// Member 'gyro'
#include "geometry_msgs/msg/detail/vector3__traits.hpp"

namespace mc_sdk_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const HighLevelRobotState & msg,
  std::ostream & out)
{
  out << "{";
  // member: pos
  {
    out << "pos: ";
    to_flow_style_yaml(msg.pos, out);
    out << ", ";
  }

  // member: vel_world
  {
    out << "vel_world: ";
    to_flow_style_yaml(msg.vel_world, out);
    out << ", ";
  }

  // member: rpy
  {
    out << "rpy: ";
    to_flow_style_yaml(msg.rpy, out);
    out << ", ";
  }

  // member: vel
  {
    out << "vel: ";
    to_flow_style_yaml(msg.vel, out);
    out << ", ";
  }

  // member: acc
  {
    out << "acc: ";
    to_flow_style_yaml(msg.acc, out);
    out << ", ";
  }

  // member: gyro
  {
    out << "gyro: ";
    to_flow_style_yaml(msg.gyro, out);
    out << ", ";
  }

  // member: q
  {
    if (msg.q.size() == 0) {
      out << "q: []";
    } else {
      out << "q: [";
      size_t pending_items = msg.q.size();
      for (auto item : msg.q) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: qd
  {
    if (msg.qd.size() == 0) {
      out << "qd: []";
    } else {
      out << "qd: [";
      size_t pending_items = msg.qd.size();
      for (auto item : msg.qd) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_int
  {
    if (msg.reserved_int.size() == 0) {
      out << "reserved_int: []";
    } else {
      out << "reserved_int: [";
      size_t pending_items = msg.reserved_int.size();
      for (auto item : msg.reserved_int) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_ft
  {
    if (msg.reserved_ft.size() == 0) {
      out << "reserved_ft: []";
    } else {
      out << "reserved_ft: [";
      size_t pending_items = msg.reserved_ft.size();
      for (auto item : msg.reserved_ft) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: reserved_uint
  {
    if (msg.reserved_uint.size() == 0) {
      out << "reserved_uint: []";
    } else {
      out << "reserved_uint: [";
      size_t pending_items = msg.reserved_uint.size();
      for (auto item : msg.reserved_uint) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HighLevelRobotState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: pos
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pos:\n";
    to_block_style_yaml(msg.pos, out, indentation + 2);
  }

  // member: vel_world
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vel_world:\n";
    to_block_style_yaml(msg.vel_world, out, indentation + 2);
  }

  // member: rpy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rpy:\n";
    to_block_style_yaml(msg.rpy, out, indentation + 2);
  }

  // member: vel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vel:\n";
    to_block_style_yaml(msg.vel, out, indentation + 2);
  }

  // member: acc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc:\n";
    to_block_style_yaml(msg.acc, out, indentation + 2);
  }

  // member: gyro
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gyro:\n";
    to_block_style_yaml(msg.gyro, out, indentation + 2);
  }

  // member: q
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.q.size() == 0) {
      out << "q: []\n";
    } else {
      out << "q:\n";
      for (auto item : msg.q) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: qd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.qd.size() == 0) {
      out << "qd: []\n";
    } else {
      out << "qd:\n";
      for (auto item : msg.qd) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_int
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_int.size() == 0) {
      out << "reserved_int: []\n";
    } else {
      out << "reserved_int:\n";
      for (auto item : msg.reserved_int) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_ft
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_ft.size() == 0) {
      out << "reserved_ft: []\n";
    } else {
      out << "reserved_ft:\n";
      for (auto item : msg.reserved_ft) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: reserved_uint
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.reserved_uint.size() == 0) {
      out << "reserved_uint: []\n";
    } else {
      out << "reserved_uint:\n";
      for (auto item : msg.reserved_uint) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HighLevelRobotState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace mc_sdk_msg

namespace rosidl_generator_traits
{

[[deprecated("use mc_sdk_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const mc_sdk_msg::msg::HighLevelRobotState & msg,
  std::ostream & out, size_t indentation = 0)
{
  mc_sdk_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use mc_sdk_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const mc_sdk_msg::msg::HighLevelRobotState & msg)
{
  return mc_sdk_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<mc_sdk_msg::msg::HighLevelRobotState>()
{
  return "mc_sdk_msg::msg::HighLevelRobotState";
}

template<>
inline const char * name<mc_sdk_msg::msg::HighLevelRobotState>()
{
  return "mc_sdk_msg/msg/HighLevelRobotState";
}

template<>
struct has_fixed_size<mc_sdk_msg::msg::HighLevelRobotState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<mc_sdk_msg::msg::HighLevelRobotState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<mc_sdk_msg::msg::HighLevelRobotState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MC_SDK_MSG__MSG__DETAIL__HIGH_LEVEL_ROBOT_STATE__TRAITS_HPP_
