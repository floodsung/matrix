// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from mc_sdk_msg:msg/LowLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__TRAITS_HPP_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "mc_sdk_msg/msg/detail/low_level_robot_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace mc_sdk_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const LowLevelRobotState & msg,
  std::ostream & out)
{
  out << "{";
  // member: q
  {
    if (msg.q.size() == 0) {
      out << "q: []";
    } else {
      out << "q: [";
      size_t pending_items = msg.q.size();
      for (auto item : msg.q) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: qd
  {
    if (msg.qd.size() == 0) {
      out << "qd: []";
    } else {
      out << "qd: [";
      size_t pending_items = msg.qd.size();
      for (auto item : msg.qd) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: tau_fb
  {
    if (msg.tau_fb.size() == 0) {
      out << "tau_fb: []";
    } else {
      out << "tau_fb: [";
      size_t pending_items = msg.tau_fb.size();
      for (auto item : msg.tau_fb) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const LowLevelRobotState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: q
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.q.size() == 0) {
      out << "q: []\n";
    } else {
      out << "q:\n";
      for (auto item : msg.q) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: qd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.qd.size() == 0) {
      out << "qd: []\n";
    } else {
      out << "qd:\n";
      for (auto item : msg.qd) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: tau_fb
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.tau_fb.size() == 0) {
      out << "tau_fb: []\n";
    } else {
      out << "tau_fb:\n";
      for (auto item : msg.tau_fb) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const LowLevelRobotState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace mc_sdk_msg

namespace rosidl_generator_traits
{

[[deprecated("use mc_sdk_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const mc_sdk_msg::msg::LowLevelRobotState & msg,
  std::ostream & out, size_t indentation = 0)
{
  mc_sdk_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use mc_sdk_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const mc_sdk_msg::msg::LowLevelRobotState & msg)
{
  return mc_sdk_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<mc_sdk_msg::msg::LowLevelRobotState>()
{
  return "mc_sdk_msg::msg::LowLevelRobotState";
}

template<>
inline const char * name<mc_sdk_msg::msg::LowLevelRobotState>()
{
  return "mc_sdk_msg/msg/LowLevelRobotState";
}

template<>
struct has_fixed_size<mc_sdk_msg::msg::LowLevelRobotState>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<mc_sdk_msg::msg::LowLevelRobotState>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<mc_sdk_msg::msg::LowLevelRobotState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__TRAITS_HPP_
