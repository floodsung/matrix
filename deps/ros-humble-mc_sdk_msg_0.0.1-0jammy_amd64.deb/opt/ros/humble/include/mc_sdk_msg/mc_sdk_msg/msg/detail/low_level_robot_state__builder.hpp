// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from mc_sdk_msg:msg/LowLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__BUILDER_HPP_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "mc_sdk_msg/msg/detail/low_level_robot_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace mc_sdk_msg
{

namespace msg
{

namespace builder
{

class Init_LowLevelRobotState_tau_fb
{
public:
  explicit Init_LowLevelRobotState_tau_fb(::mc_sdk_msg::msg::LowLevelRobotState & msg)
  : msg_(msg)
  {}
  ::mc_sdk_msg::msg::LowLevelRobotState tau_fb(::mc_sdk_msg::msg::LowLevelRobotState::_tau_fb_type arg)
  {
    msg_.tau_fb = std::move(arg);
    return std::move(msg_);
  }

private:
  ::mc_sdk_msg::msg::LowLevelRobotState msg_;
};

class Init_LowLevelRobotState_qd
{
public:
  explicit Init_LowLevelRobotState_qd(::mc_sdk_msg::msg::LowLevelRobotState & msg)
  : msg_(msg)
  {}
  Init_LowLevelRobotState_tau_fb qd(::mc_sdk_msg::msg::LowLevelRobotState::_qd_type arg)
  {
    msg_.qd = std::move(arg);
    return Init_LowLevelRobotState_tau_fb(msg_);
  }

private:
  ::mc_sdk_msg::msg::LowLevelRobotState msg_;
};

class Init_LowLevelRobotState_q
{
public:
  Init_LowLevelRobotState_q()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_LowLevelRobotState_qd q(::mc_sdk_msg::msg::LowLevelRobotState::_q_type arg)
  {
    msg_.q = std::move(arg);
    return Init_LowLevelRobotState_qd(msg_);
  }

private:
  ::mc_sdk_msg::msg::LowLevelRobotState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::mc_sdk_msg::msg::LowLevelRobotState>()
{
  return mc_sdk_msg::msg::builder::Init_LowLevelRobotState_q();
}

}  // namespace mc_sdk_msg

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_ROBOT_STATE__BUILDER_HPP_
