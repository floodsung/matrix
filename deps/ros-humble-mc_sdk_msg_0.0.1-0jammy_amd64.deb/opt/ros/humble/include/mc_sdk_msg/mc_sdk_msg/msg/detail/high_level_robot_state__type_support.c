// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "mc_sdk_msg/msg/detail/high_level_robot_state__rosidl_typesupport_introspection_c.h"
#include "mc_sdk_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "mc_sdk_msg/msg/detail/high_level_robot_state__functions.h"
#include "mc_sdk_msg/msg/detail/high_level_robot_state__struct.h"


// Include directives for member types
// Member `pos`
// Member `vel_world`
// Member `rpy`
// Member `vel`
// Member `acc`
// Member `gyro`
#include "geometry_msgs/msg/vector3.h"
// Member `pos`
// Member `vel_world`
// Member `rpy`
// Member `vel`
// Member `acc`
// Member `gyro`
#include "geometry_msgs/msg/detail/vector3__rosidl_typesupport_introspection_c.h"
// Member `reserved_int`
// Member `reserved_ft`
// Member `reserved_uint`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  mc_sdk_msg__msg__HighLevelRobotState__init(message_memory);
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_fini_function(void * message_memory)
{
  mc_sdk_msg__msg__HighLevelRobotState__fini(message_memory);
}

size_t mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__q(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__q(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__q(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__q(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__q(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__q(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__q(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__qd(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__qd(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__qd(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__qd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__qd(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__qd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__qd(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__reserved_int(
  const void * untyped_member)
{
  const rosidl_runtime_c__int32__Sequence * member =
    (const rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return member->size;
}

const void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_int(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int32__Sequence * member =
    (const rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_int(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int32__Sequence * member =
    (rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return &member->data[index];
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__reserved_int(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int32_t * item =
    ((const int32_t *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_int(untyped_member, index));
  int32_t * value =
    (int32_t *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__reserved_int(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int32_t * item =
    ((int32_t *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_int(untyped_member, index));
  const int32_t * value =
    (const int32_t *)(untyped_value);
  *item = *value;
}

bool mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__resize_function__HighLevelRobotState__reserved_int(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int32__Sequence * member =
    (rosidl_runtime_c__int32__Sequence *)(untyped_member);
  rosidl_runtime_c__int32__Sequence__fini(member);
  return rosidl_runtime_c__int32__Sequence__init(member, size);
}

size_t mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__reserved_ft(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_ft(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_ft(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__reserved_ft(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_ft(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__reserved_ft(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_ft(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__resize_function__HighLevelRobotState__reserved_ft(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

size_t mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__reserved_uint(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return member->size;
}

const void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_uint(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_uint(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__reserved_uint(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_uint(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__reserved_uint(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_uint(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

bool mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__resize_function__HighLevelRobotState__reserved_uint(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  rosidl_runtime_c__uint32__Sequence__fini(member);
  return rosidl_runtime_c__uint32__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array[11] = {
  {
    "pos",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, pos),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "vel_world",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, vel_world),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "rpy",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, rpy),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "vel",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, vel),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "acc",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, acc),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "gyro",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, gyro),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "q",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, q),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__q,  // size() function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__q,  // get_const(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__q,  // get(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__q,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__q,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "qd",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, qd),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__qd,  // size() function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__qd,  // get_const(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__qd,  // get(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__qd,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__qd,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reserved_int",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, reserved_int),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__reserved_int,  // size() function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_int,  // get_const(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_int,  // get(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__reserved_int,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__reserved_int,  // assign(index, value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__resize_function__HighLevelRobotState__reserved_int  // resize(index) function pointer
  },
  {
    "reserved_ft",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, reserved_ft),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__reserved_ft,  // size() function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_ft,  // get_const(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_ft,  // get(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__reserved_ft,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__reserved_ft,  // assign(index, value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__resize_function__HighLevelRobotState__reserved_ft  // resize(index) function pointer
  },
  {
    "reserved_uint",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__HighLevelRobotState, reserved_uint),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__size_function__HighLevelRobotState__reserved_uint,  // size() function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__HighLevelRobotState__reserved_uint,  // get_const(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__get_function__HighLevelRobotState__reserved_uint,  // get(index) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__HighLevelRobotState__reserved_uint,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__assign_function__HighLevelRobotState__reserved_uint,  // assign(index, value) function pointer
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__resize_function__HighLevelRobotState__reserved_uint  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_members = {
  "mc_sdk_msg__msg",  // message namespace
  "HighLevelRobotState",  // message name
  11,  // number of fields
  sizeof(mc_sdk_msg__msg__HighLevelRobotState),
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array,  // message members
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_init_function,  // function to initialize message memory (memory has to be allocated)
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_type_support_handle = {
  0,
  &mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_mc_sdk_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, mc_sdk_msg, msg, HighLevelRobotState)() {
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Vector3)();
  if (!mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_type_support_handle.typesupport_identifier) {
    mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &mc_sdk_msg__msg__HighLevelRobotState__rosidl_typesupport_introspection_c__HighLevelRobotState_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
