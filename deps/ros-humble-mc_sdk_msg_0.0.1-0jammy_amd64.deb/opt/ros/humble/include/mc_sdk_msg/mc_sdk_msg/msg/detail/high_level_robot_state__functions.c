// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice
#include "mc_sdk_msg/msg/detail/high_level_robot_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `pos`
// Member `vel_world`
// Member `rpy`
// Member `vel`
// Member `acc`
// Member `gyro`
#include "geometry_msgs/msg/detail/vector3__functions.h"
// Member `reserved_int`
// Member `reserved_ft`
// Member `reserved_uint`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
mc_sdk_msg__msg__HighLevelRobotState__init(mc_sdk_msg__msg__HighLevelRobotState * msg)
{
  if (!msg) {
    return false;
  }
  // pos
  if (!geometry_msgs__msg__Vector3__init(&msg->pos)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // vel_world
  if (!geometry_msgs__msg__Vector3__init(&msg->vel_world)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // rpy
  if (!geometry_msgs__msg__Vector3__init(&msg->rpy)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // vel
  if (!geometry_msgs__msg__Vector3__init(&msg->vel)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // acc
  if (!geometry_msgs__msg__Vector3__init(&msg->acc)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // gyro
  if (!geometry_msgs__msg__Vector3__init(&msg->gyro)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // q
  // qd
  // reserved_int
  if (!rosidl_runtime_c__int32__Sequence__init(&msg->reserved_int, 0)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // reserved_ft
  if (!rosidl_runtime_c__double__Sequence__init(&msg->reserved_ft, 0)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  // reserved_uint
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->reserved_uint, 0)) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
    return false;
  }
  return true;
}

void
mc_sdk_msg__msg__HighLevelRobotState__fini(mc_sdk_msg__msg__HighLevelRobotState * msg)
{
  if (!msg) {
    return;
  }
  // pos
  geometry_msgs__msg__Vector3__fini(&msg->pos);
  // vel_world
  geometry_msgs__msg__Vector3__fini(&msg->vel_world);
  // rpy
  geometry_msgs__msg__Vector3__fini(&msg->rpy);
  // vel
  geometry_msgs__msg__Vector3__fini(&msg->vel);
  // acc
  geometry_msgs__msg__Vector3__fini(&msg->acc);
  // gyro
  geometry_msgs__msg__Vector3__fini(&msg->gyro);
  // q
  // qd
  // reserved_int
  rosidl_runtime_c__int32__Sequence__fini(&msg->reserved_int);
  // reserved_ft
  rosidl_runtime_c__double__Sequence__fini(&msg->reserved_ft);
  // reserved_uint
  rosidl_runtime_c__uint32__Sequence__fini(&msg->reserved_uint);
}

bool
mc_sdk_msg__msg__HighLevelRobotState__are_equal(const mc_sdk_msg__msg__HighLevelRobotState * lhs, const mc_sdk_msg__msg__HighLevelRobotState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // pos
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->pos), &(rhs->pos)))
  {
    return false;
  }
  // vel_world
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->vel_world), &(rhs->vel_world)))
  {
    return false;
  }
  // rpy
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->rpy), &(rhs->rpy)))
  {
    return false;
  }
  // vel
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->vel), &(rhs->vel)))
  {
    return false;
  }
  // acc
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->acc), &(rhs->acc)))
  {
    return false;
  }
  // gyro
  if (!geometry_msgs__msg__Vector3__are_equal(
      &(lhs->gyro), &(rhs->gyro)))
  {
    return false;
  }
  // q
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->q[i] != rhs->q[i]) {
      return false;
    }
  }
  // qd
  for (size_t i = 0; i < 12; ++i) {
    if (lhs->qd[i] != rhs->qd[i]) {
      return false;
    }
  }
  // reserved_int
  if (!rosidl_runtime_c__int32__Sequence__are_equal(
      &(lhs->reserved_int), &(rhs->reserved_int)))
  {
    return false;
  }
  // reserved_ft
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->reserved_ft), &(rhs->reserved_ft)))
  {
    return false;
  }
  // reserved_uint
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->reserved_uint), &(rhs->reserved_uint)))
  {
    return false;
  }
  return true;
}

bool
mc_sdk_msg__msg__HighLevelRobotState__copy(
  const mc_sdk_msg__msg__HighLevelRobotState * input,
  mc_sdk_msg__msg__HighLevelRobotState * output)
{
  if (!input || !output) {
    return false;
  }
  // pos
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->pos), &(output->pos)))
  {
    return false;
  }
  // vel_world
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->vel_world), &(output->vel_world)))
  {
    return false;
  }
  // rpy
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->rpy), &(output->rpy)))
  {
    return false;
  }
  // vel
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->vel), &(output->vel)))
  {
    return false;
  }
  // acc
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->acc), &(output->acc)))
  {
    return false;
  }
  // gyro
  if (!geometry_msgs__msg__Vector3__copy(
      &(input->gyro), &(output->gyro)))
  {
    return false;
  }
  // q
  for (size_t i = 0; i < 12; ++i) {
    output->q[i] = input->q[i];
  }
  // qd
  for (size_t i = 0; i < 12; ++i) {
    output->qd[i] = input->qd[i];
  }
  // reserved_int
  if (!rosidl_runtime_c__int32__Sequence__copy(
      &(input->reserved_int), &(output->reserved_int)))
  {
    return false;
  }
  // reserved_ft
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->reserved_ft), &(output->reserved_ft)))
  {
    return false;
  }
  // reserved_uint
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->reserved_uint), &(output->reserved_uint)))
  {
    return false;
  }
  return true;
}

mc_sdk_msg__msg__HighLevelRobotState *
mc_sdk_msg__msg__HighLevelRobotState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__HighLevelRobotState * msg = (mc_sdk_msg__msg__HighLevelRobotState *)allocator.allocate(sizeof(mc_sdk_msg__msg__HighLevelRobotState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(mc_sdk_msg__msg__HighLevelRobotState));
  bool success = mc_sdk_msg__msg__HighLevelRobotState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
mc_sdk_msg__msg__HighLevelRobotState__destroy(mc_sdk_msg__msg__HighLevelRobotState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    mc_sdk_msg__msg__HighLevelRobotState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
mc_sdk_msg__msg__HighLevelRobotState__Sequence__init(mc_sdk_msg__msg__HighLevelRobotState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__HighLevelRobotState * data = NULL;

  if (size) {
    data = (mc_sdk_msg__msg__HighLevelRobotState *)allocator.zero_allocate(size, sizeof(mc_sdk_msg__msg__HighLevelRobotState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = mc_sdk_msg__msg__HighLevelRobotState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        mc_sdk_msg__msg__HighLevelRobotState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
mc_sdk_msg__msg__HighLevelRobotState__Sequence__fini(mc_sdk_msg__msg__HighLevelRobotState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      mc_sdk_msg__msg__HighLevelRobotState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

mc_sdk_msg__msg__HighLevelRobotState__Sequence *
mc_sdk_msg__msg__HighLevelRobotState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  mc_sdk_msg__msg__HighLevelRobotState__Sequence * array = (mc_sdk_msg__msg__HighLevelRobotState__Sequence *)allocator.allocate(sizeof(mc_sdk_msg__msg__HighLevelRobotState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = mc_sdk_msg__msg__HighLevelRobotState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
mc_sdk_msg__msg__HighLevelRobotState__Sequence__destroy(mc_sdk_msg__msg__HighLevelRobotState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    mc_sdk_msg__msg__HighLevelRobotState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
mc_sdk_msg__msg__HighLevelRobotState__Sequence__are_equal(const mc_sdk_msg__msg__HighLevelRobotState__Sequence * lhs, const mc_sdk_msg__msg__HighLevelRobotState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!mc_sdk_msg__msg__HighLevelRobotState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
mc_sdk_msg__msg__HighLevelRobotState__Sequence__copy(
  const mc_sdk_msg__msg__HighLevelRobotState__Sequence * input,
  mc_sdk_msg__msg__HighLevelRobotState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(mc_sdk_msg__msg__HighLevelRobotState);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    mc_sdk_msg__msg__HighLevelRobotState * data =
      (mc_sdk_msg__msg__HighLevelRobotState *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!mc_sdk_msg__msg__HighLevelRobotState__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          mc_sdk_msg__msg__HighLevelRobotState__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!mc_sdk_msg__msg__HighLevelRobotState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
