// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from mc_sdk_msg:msg/LowLevelRobotState.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "mc_sdk_msg/msg/detail/low_level_robot_state__rosidl_typesupport_introspection_c.h"
#include "mc_sdk_msg/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "mc_sdk_msg/msg/detail/low_level_robot_state__functions.h"
#include "mc_sdk_msg/msg/detail/low_level_robot_state__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  mc_sdk_msg__msg__LowLevelRobotState__init(message_memory);
}

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_fini_function(void * message_memory)
{
  mc_sdk_msg__msg__LowLevelRobotState__fini(message_memory);
}

size_t mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__size_function__LowLevelRobotState__q(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__q(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__q(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__LowLevelRobotState__q(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__q(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__assign_function__LowLevelRobotState__q(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__q(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__size_function__LowLevelRobotState__qd(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__qd(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__qd(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__LowLevelRobotState__qd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__qd(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__assign_function__LowLevelRobotState__qd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__qd(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

size_t mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__size_function__LowLevelRobotState__tau_fb(
  const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__tau_fb(
  const void * untyped_member, size_t index)
{
  const float * member =
    (const float *)(untyped_member);
  return &member[index];
}

void * mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__tau_fb(
  void * untyped_member, size_t index)
{
  float * member =
    (float *)(untyped_member);
  return &member[index];
}

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__LowLevelRobotState__tau_fb(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__tau_fb(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__assign_function__LowLevelRobotState__tau_fb(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__tau_fb(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_member_array[3] = {
  {
    "q",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__LowLevelRobotState, q),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__size_function__LowLevelRobotState__q,  // size() function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__q,  // get_const(index) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__q,  // get(index) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__LowLevelRobotState__q,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__assign_function__LowLevelRobotState__q,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "qd",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__LowLevelRobotState, qd),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__size_function__LowLevelRobotState__qd,  // size() function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__qd,  // get_const(index) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__qd,  // get(index) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__LowLevelRobotState__qd,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__assign_function__LowLevelRobotState__qd,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "tau_fb",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg__msg__LowLevelRobotState, tau_fb),  // bytes offset in struct
    NULL,  // default value
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__size_function__LowLevelRobotState__tau_fb,  // size() function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_const_function__LowLevelRobotState__tau_fb,  // get_const(index) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__get_function__LowLevelRobotState__tau_fb,  // get(index) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__fetch_function__LowLevelRobotState__tau_fb,  // fetch(index, &value) function pointer
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__assign_function__LowLevelRobotState__tau_fb,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_members = {
  "mc_sdk_msg__msg",  // message namespace
  "LowLevelRobotState",  // message name
  3,  // number of fields
  sizeof(mc_sdk_msg__msg__LowLevelRobotState),
  mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_member_array,  // message members
  mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_init_function,  // function to initialize message memory (memory has to be allocated)
  mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_type_support_handle = {
  0,
  &mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_mc_sdk_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, mc_sdk_msg, msg, LowLevelRobotState)() {
  if (!mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_type_support_handle.typesupport_identifier) {
    mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &mc_sdk_msg__msg__LowLevelRobotState__rosidl_typesupport_introspection_c__LowLevelRobotState_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
