// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from mc_sdk_msg:msg/LowLevelCmd.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__TRAITS_HPP_
#define MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "mc_sdk_msg/msg/detail/low_level_cmd__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace mc_sdk_msg
{

namespace msg
{

inline void to_flow_style_yaml(
  const LowLevelCmd & msg,
  std::ostream & out)
{
  out << "{";
  // member: q_des
  {
    if (msg.q_des.size() == 0) {
      out << "q_des: []";
    } else {
      out << "q_des: [";
      size_t pending_items = msg.q_des.size();
      for (auto item : msg.q_des) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: qd_des
  {
    if (msg.qd_des.size() == 0) {
      out << "qd_des: []";
    } else {
      out << "qd_des: [";
      size_t pending_items = msg.qd_des.size();
      for (auto item : msg.qd_des) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: kp
  {
    if (msg.kp.size() == 0) {
      out << "kp: []";
    } else {
      out << "kp: [";
      size_t pending_items = msg.kp.size();
      for (auto item : msg.kp) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: kd
  {
    if (msg.kd.size() == 0) {
      out << "kd: []";
    } else {
      out << "kd: [";
      size_t pending_items = msg.kd.size();
      for (auto item : msg.kd) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const LowLevelCmd & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: q_des
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.q_des.size() == 0) {
      out << "q_des: []\n";
    } else {
      out << "q_des:\n";
      for (auto item : msg.q_des) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: qd_des
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.qd_des.size() == 0) {
      out << "qd_des: []\n";
    } else {
      out << "qd_des:\n";
      for (auto item : msg.qd_des) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: kp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.kp.size() == 0) {
      out << "kp: []\n";
    } else {
      out << "kp:\n";
      for (auto item : msg.kp) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: kd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.kd.size() == 0) {
      out << "kd: []\n";
    } else {
      out << "kd:\n";
      for (auto item : msg.kd) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const LowLevelCmd & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace mc_sdk_msg

namespace rosidl_generator_traits
{

[[deprecated("use mc_sdk_msg::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const mc_sdk_msg::msg::LowLevelCmd & msg,
  std::ostream & out, size_t indentation = 0)
{
  mc_sdk_msg::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use mc_sdk_msg::msg::to_yaml() instead")]]
inline std::string to_yaml(const mc_sdk_msg::msg::LowLevelCmd & msg)
{
  return mc_sdk_msg::msg::to_yaml(msg);
}

template<>
inline const char * data_type<mc_sdk_msg::msg::LowLevelCmd>()
{
  return "mc_sdk_msg::msg::LowLevelCmd";
}

template<>
inline const char * name<mc_sdk_msg::msg::LowLevelCmd>()
{
  return "mc_sdk_msg/msg/LowLevelCmd";
}

template<>
struct has_fixed_size<mc_sdk_msg::msg::LowLevelCmd>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<mc_sdk_msg::msg::LowLevelCmd>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<mc_sdk_msg::msg::LowLevelCmd>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MC_SDK_MSG__MSG__DETAIL__LOW_LEVEL_CMD__TRAITS_HPP_
