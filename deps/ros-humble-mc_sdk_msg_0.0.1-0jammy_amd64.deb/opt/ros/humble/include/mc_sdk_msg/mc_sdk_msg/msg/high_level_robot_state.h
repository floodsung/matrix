// generated from rosidl_generator_c/resource/idl.h.em
// with input from mc_sdk_msg:msg/HighLevelRobotState.idl
// generated code does not contain a copyright notice

#ifndef MC_SDK_MSG__MSG__HIGH_LEVEL_ROBOT_STATE_H_
#define MC_SDK_MSG__MSG__HIGH_LEVEL_ROBOT_STATE_H_

#include "mc_sdk_msg/msg/detail/high_level_robot_state__struct.h"
#include "mc_sdk_msg/msg/detail/high_level_robot_state__functions.h"
#include "mc_sdk_msg/msg/detail/high_level_robot_state__type_support.h"

#endif  // MC_SDK_MSG__MSG__HIGH_LEVEL_ROBOT_STATE_H_
