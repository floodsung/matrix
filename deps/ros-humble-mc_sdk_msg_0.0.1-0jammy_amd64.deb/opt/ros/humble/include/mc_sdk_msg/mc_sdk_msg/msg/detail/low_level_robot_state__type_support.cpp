// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from mc_sdk_msg:msg/LowLevelRobotState.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "mc_sdk_msg/msg/detail/low_level_robot_state__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace mc_sdk_msg
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void LowLevelRobotState_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) mc_sdk_msg::msg::LowLevelRobotState(_init);
}

void LowLevelRobotState_fini_function(void * message_memory)
{
  auto typed_message = static_cast<mc_sdk_msg::msg::LowLevelRobotState *>(message_memory);
  typed_message->~LowLevelRobotState();
}

size_t size_function__LowLevelRobotState__q(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__LowLevelRobotState__q(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__LowLevelRobotState__q(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__LowLevelRobotState__q(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__LowLevelRobotState__q(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__LowLevelRobotState__q(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__LowLevelRobotState__q(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

size_t size_function__LowLevelRobotState__qd(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__LowLevelRobotState__qd(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__LowLevelRobotState__qd(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__LowLevelRobotState__qd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__LowLevelRobotState__qd(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__LowLevelRobotState__qd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__LowLevelRobotState__qd(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

size_t size_function__LowLevelRobotState__tau_fb(const void * untyped_member)
{
  (void)untyped_member;
  return 12;
}

const void * get_const_function__LowLevelRobotState__tau_fb(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void * get_function__LowLevelRobotState__tau_fb(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<float, 12> *>(untyped_member);
  return &member[index];
}

void fetch_function__LowLevelRobotState__tau_fb(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const float *>(
    get_const_function__LowLevelRobotState__tau_fb(untyped_member, index));
  auto & value = *reinterpret_cast<float *>(untyped_value);
  value = item;
}

void assign_function__LowLevelRobotState__tau_fb(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<float *>(
    get_function__LowLevelRobotState__tau_fb(untyped_member, index));
  const auto & value = *reinterpret_cast<const float *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember LowLevelRobotState_message_member_array[3] = {
  {
    "q",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::LowLevelRobotState, q),  // bytes offset in struct
    nullptr,  // default value
    size_function__LowLevelRobotState__q,  // size() function pointer
    get_const_function__LowLevelRobotState__q,  // get_const(index) function pointer
    get_function__LowLevelRobotState__q,  // get(index) function pointer
    fetch_function__LowLevelRobotState__q,  // fetch(index, &value) function pointer
    assign_function__LowLevelRobotState__q,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "qd",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::LowLevelRobotState, qd),  // bytes offset in struct
    nullptr,  // default value
    size_function__LowLevelRobotState__qd,  // size() function pointer
    get_const_function__LowLevelRobotState__qd,  // get_const(index) function pointer
    get_function__LowLevelRobotState__qd,  // get(index) function pointer
    fetch_function__LowLevelRobotState__qd,  // fetch(index, &value) function pointer
    assign_function__LowLevelRobotState__qd,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "tau_fb",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    12,  // array size
    false,  // is upper bound
    offsetof(mc_sdk_msg::msg::LowLevelRobotState, tau_fb),  // bytes offset in struct
    nullptr,  // default value
    size_function__LowLevelRobotState__tau_fb,  // size() function pointer
    get_const_function__LowLevelRobotState__tau_fb,  // get_const(index) function pointer
    get_function__LowLevelRobotState__tau_fb,  // get(index) function pointer
    fetch_function__LowLevelRobotState__tau_fb,  // fetch(index, &value) function pointer
    assign_function__LowLevelRobotState__tau_fb,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers LowLevelRobotState_message_members = {
  "mc_sdk_msg::msg",  // message namespace
  "LowLevelRobotState",  // message name
  3,  // number of fields
  sizeof(mc_sdk_msg::msg::LowLevelRobotState),
  LowLevelRobotState_message_member_array,  // message members
  LowLevelRobotState_init_function,  // function to initialize message memory (memory has to be allocated)
  LowLevelRobotState_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t LowLevelRobotState_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &LowLevelRobotState_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace mc_sdk_msg


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<mc_sdk_msg::msg::LowLevelRobotState>()
{
  return &::mc_sdk_msg::msg::rosidl_typesupport_introspection_cpp::LowLevelRobotState_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, mc_sdk_msg, msg, LowLevelRobotState)() {
  return &::mc_sdk_msg::msg::rosidl_typesupport_introspection_cpp::LowLevelRobotState_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
